package com.wdzl.ymyy.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.entity.Address;
import com.wdzl.ymyy.entity.Jiezhongdian;
import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.entity.Yuyue;
import com.wdzl.ymyy.mapper.AddressMapper;
import com.wdzl.ymyy.mapper.JiezhongdianMapper;
import com.wdzl.ymyy.mapper.JiezhongdianWorkerMapper;
import com.wdzl.ymyy.mapper.YuyueMapper;
import com.wdzl.ymyy.service.IYuyueService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wdzl.ymyy.utils.Global;
import com.wdzl.ymyy.utils.QRCodeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.UUID;

/**
 * <p>
 * 预约记录 服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class YuyueServiceImpl extends ServiceImpl<YuyueMapper, Yuyue> implements IYuyueService {

    @Resource
    private JiezhongdianMapper jiezhongdianMapper;
    @Autowired
    private JiezhongdianWorkerMapper jiezhongdianWorkerMapper;
    @Autowired
    private AddressMapper addressMapper;
    @Override
    public void yuyue(Yuyue yuyue)  {
        yuyue.setStatus(0);
        Jiezhongdian jiezhongdian = jiezhongdianMapper.selectById(yuyue.getJiezhongdianId());
        yuyue.setJiezhongdianName(jiezhongdian.getName());
        yuyue.setJiezhongdianAddress(jiezhongdian.getAddress());
        // 判断是否有未完成的预约
        QueryWrapper<Yuyue> qw =new QueryWrapper<>();
        qw.eq("user_id",yuyue.getUserId());
//        qw.eq("",yuyue.getJiezhongdianId());
        qw.eq("status","0");
        if( getBaseMapper().selectCount(qw)>0){
            throw new RuntimeException("Please arrive before the appointment");
        }
        yuyue.setQrCodePath("");
        save(yuyue);
        System.out.println(yuyue.getId());
        // 根据id 生成预约二维码
        File file = new File (Global.getImgDirFile(), UUID.randomUUID().toString()+".png");
        try {
            String imgpath =  QRCodeUtil.generateQRCode(JSONObject.toJSONString(yuyue) + "", 400, 400, "png", file.getPath());
            yuyue.setQrCodePath(imgpath.replace("\\","/"));
            updateById(yuyue);
        }catch (Exception e){
            throw  new RuntimeException("生成二维码异常",e);
        }

    }
    @Override
    public void yuyueaddress(Address address,String userId){
        // 根据id 生成预约二维码
        Yuyue yuyue=new Yuyue();
        yuyue.setStatus(0);
        yuyue.setUserId(Integer.parseInt(userId));
        yuyue.setJiezhongdianId(address.getId());
        yuyue.setJiezhongdianName(address.getAddressname());


//        Jiezhongdian jiezhongdian = jiezhongdianMapper.selectById(yuyue.getJiezhongdianId());
//        yuyue.setJiezhongdianName(jiezhongdian.getName());
//        yuyue.setJiezhongdianAddress(jiezhongdian.getAddress());
//        // 判断是否有未完成的预约
        QueryWrapper<Yuyue> qw =new QueryWrapper<>();
        qw.eq("user_id",yuyue.getUserId());
        qw.eq("jiezhongdian_id",yuyue.getJiezhongdianId());
        qw.eq("status","0");
        if( getBaseMapper().selectCount(qw)>0){
            throw new RuntimeException("Please arrive before the appointment");
        }
        yuyue.setQrCodePath("");
        //save(yuyue);
        System.out.println(yuyue.getId());
        // 根据id 生成预约二维码
        File file = new File (Global.getImgDirFile(), UUID.randomUUID().toString()+".png");
        try {
            String imgpath =  QRCodeUtil.generateQRCode(JSONObject.toJSONString(yuyue) + "", 400, 400, "png", file.getPath());
            System.out.println(imgpath);
            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String dateNowStr = sdf.format(d);
            yuyue.setYuyueriqi(LocalDate.parse(dateNowStr));
            //yuyue.setQrCodePath(imgpath.replace("\\","/"));
            yuyue.setQrCodePath(imgpath);
            save(yuyue);
            //updateById(yuyue);
        }catch (Exception e){
            throw  new RuntimeException("生成二维码异常",e);
        }
    }
    @Override
    public void yuyuechenggong(Yuyue yuyue,String workerId){
        JiezhongdianWorker worker = jiezhongdianWorkerMapper.selectById(Integer.parseInt(workerId));
        System.out.println(worker.toString());
//        if(yuyue.getJiezhongdianId().longValue() != worker.getJiezhongdianId().longValue()){
//            throw  new RuntimeException("预约地点与接种地点不一致");
//        }
        System.out.println(1);
        Address address=addressMapper.selectById(yuyue.getJiezhongdianId());
        address.setNum(address.getNum()-1);
        addressMapper.updateById(address);
        QueryWrapper<Yuyue> qw =new QueryWrapper<>();
        qw.eq("user_id",yuyue.getUserId());
        qw.eq("jiezhongdian_id",yuyue.getJiezhongdianId());
//        qw.eq("",yuyue.getJiezhongdianId());
        qw.eq("status","0");
        getBaseMapper().delete(qw);

    }

}
