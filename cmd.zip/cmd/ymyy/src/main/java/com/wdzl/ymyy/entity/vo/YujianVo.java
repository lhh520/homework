package com.wdzl.ymyy.entity.vo;

import io.swagger.models.auth.In;
import lombok.Data;

import java.time.LocalDateTime;
@Data
public class YujianVo {

    private Integer id;
    private String jiezhongren;
    private String isFuyao;
    private Double gaoya;
    private Double diya;
    private Double tiwen;
    private String creator;
    private LocalDateTime createTime;
    private String jiezhongdianId;
    private Integer yuyueId;


}
