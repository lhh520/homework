package com.wdzl.ymyy.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.annotation.PassToken;
import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.entity.User;
import com.wdzl.ymyy.service.IJiezhongdianWorkerService;
import com.wdzl.ymyy.service.UserService;
import com.wdzl.ymyy.utils.JwtUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.util.StringUtils;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "手机用户登录与验证接口")
@CrossOrigin
@RestController
public class LoginController {

    @Resource
    private UserService userService;

    @Autowired
    private IJiezhongdianWorkerService iJiezhongdianWorkerService;

    // 接种人员登录
    @ApiOperation("接种人员用户登录")
    @RequestMapping(value = "/login", method = {RequestMethod.POST})
    public Result login(@RequestBody UsernameAndPw up) {
        try {
            if (StringUtils.isEmpty(up.getUsername())) {
                throw new RuntimeException("用户名不能为空");
            }
            if (StringUtils.isEmpty(up.getPassword())) {
                throw new RuntimeException("密码不能为空");
            }
            if (StringUtils.isEmpty(up.getUserType())) {
                throw new RuntimeException("用户类型不能为空");
            }
            if ("jiezhongzhe".equals(up.getUserType())) {
                QueryWrapper<User> qw = new QueryWrapper<>();
                qw.eq("username", up.getUsername());
                List<User> list = userService.list(qw);
                if (list.size() > 1) {
                    return Result.error("存在多个用户");
                } else if (list.size() == 0) {
                    return Result.error("查无此用户");
                } else {
                    // 查到用户
                    User loginUser = list.get(0);
                    if (!up.getPassword().equals(loginUser.getPassword())) {
                        return Result.error("密码错误");
                    } else {
                        loginUser.setPassword(null);
                        JSONObject obj = new JSONObject();
                        obj.put("loginUser", loginUser);
                        obj.put("userType","jiezhongzhe");
                        obj.put("token", JwtUtils.createToken(loginUser.getId() + "", loginUser.getUsername(), loginUser.getRealName(), "jiezhongzhe"));
                        return Result.ok(obj);
                    }
                }
            } else if ("worker".equals(up.getUserType())) {
                QueryWrapper<JiezhongdianWorker> qw = new QueryWrapper<>();
                qw.eq("username", up.getUsername());
                List<JiezhongdianWorker> list = iJiezhongdianWorkerService.list(qw);
                if (list.size() > 1) {
                    return Result.error("存在多个用户");
                } else if (list.size() == 0) {
                    return Result.error("查无此用户");
                } else {
                    // 查到用户
                    JiezhongdianWorker loginUser = list.get(0);
                    if (!up.getPassword().equals(loginUser.getPassword())) {
                        return Result.error("密码错误");
                    } else {
                        loginUser.setPassword(null);
                        JSONObject obj = new JSONObject();
                        obj.put("loginUser", loginUser);
                        obj.put("userType","worker");
                        obj.put("token", JwtUtils.createToken(loginUser.getId() + "", loginUser.getUsername(), loginUser.getRealName(), "worker"));
                        return Result.ok(obj);
                    }
                }
            } else {
                throw new RuntimeException("用户类型有误");
            }
        } catch (Exception e) {
            return Result.error("登录失败");
        }
    }

    // 登录（不验证）
    @CrossOrigin(origins = "*")
    @PassToken(required = false)
    @RequestMapping(value = "/validate", method = RequestMethod.POST)
    public Result validate(@RequestBody UserToken userToken) {
        System.out.println(">>>" + userToken);
        try {
            // 获取 token 中的 user Name
            String userType = JwtUtils.getClaimByName(userToken.getToken(),"userType").asString();
            if(!userToken.getUserType().equals(userType)){
                throw new RuntimeException("用户的身份不符");
            }
            String userId = JwtUtils.getAudience(userToken.getToken());
            System.out.println(">>>" + userId);
            JwtUtils.verifyToken(userToken.getToken(), userId);
            return Result.ok("验证成功");
        } catch (Exception e) {
            Result result = Result.error("验证失败");
            result.setCode(510);
            return result;
        }

    }

}
