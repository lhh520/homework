package com.wdzl.ymyy.service.impl;

import com.wdzl.ymyy.entity.Address;
import com.wdzl.ymyy.mapper.AddressMapper;
import com.wdzl.ymyy.service.AddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2023-03-15
 */
@Service
public class AddressServiceImpl extends ServiceImpl<AddressMapper, Address> implements AddressService {

}
