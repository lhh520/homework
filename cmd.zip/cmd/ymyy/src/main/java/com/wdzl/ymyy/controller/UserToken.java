package com.wdzl.ymyy.controller;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@ApiModel(value = "用户token")
public class UserToken {
    @ApiModelProperty(value = "token",required = true)
    private String token;
    @ApiModelProperty(value = "用户类型,两种类型(jiezhongzhe、worker)",required = true)
    private String userType;
}
