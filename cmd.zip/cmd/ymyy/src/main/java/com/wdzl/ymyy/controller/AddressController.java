package com.wdzl.ymyy.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2023-03-15
 */
@RestController
@RequestMapping("/address")
public class AddressController {

}

