package com.wdzl.ymyy.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="YimiaoLishi对象", description="")
public class YimiaoLishi implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private Integer jiezhongrenId;

    private Integer yimiaoId;

    @ApiModelProperty(value = "疫苗种类")
    private String yimiaoZhonglei;

    @ApiModelProperty(value = "疫苗生产企业")
    private String yimiaoShengchanqiye;

    private Integer zhenshu;

    private Integer yidazhenshu;

    private LocalDateTime firstTime;

    private LocalDateTime updateTime;


}
