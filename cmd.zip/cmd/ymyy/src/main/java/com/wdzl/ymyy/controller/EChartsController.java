package com.wdzl.ymyy.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.entity.vo.DataVos;
import com.wdzl.ymyy.entity.vo.EChartsVo;
import com.wdzl.ymyy.entity.vo.Ijiezhong;
import com.wdzl.ymyy.service.*;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.utils.utils.DateUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.crypto.Data;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@CrossOrigin
@Api(tags="柱状图")
@RestController
@RequestMapping("/eCharts")
public class EChartsController {

    @Autowired
    private IYuyueService yuyueService;

    @Autowired
    private IYuejianService yuejianService;

    @Autowired
    private IJiezhongService jiezhongService;

    @Autowired
    private ILiuguanService liuguanService;

    @Autowired
    private IQiandaoService qiandaoService;

    @ApiOperation("获取柱状图")
    @CrossOrigin
    @GetMapping("/charts")
    public DataVo<Integer> pageQuery(){
        //预约总人数
        int count = yuyueService.count();
        //预检总人数
        int count1 = yuejianService.count();
        //签到总人数
        int count2 = qiandaoService.count();
        //接种总人数
        int count3 = jiezhongService.count();
        //留观总人数
        int count4 = liuguanService.count();
//        EChars eChars = new EChars();
//        eChars.setYuyue(count);
//        eChars.setYujian(count1);
//        eChars.setJiezhong(count2);
        List<Integer> list=new ArrayList<>();
        list.add(count);
        list.add(count1);
        list.add(count2);
        list.add(count3);
        list.add(count4);

        DataVo<Integer> eCharsDataVo = new DataVo<>();
        eCharsDataVo.setCode(0);
        eCharsDataVo.setMsg("成功获取数据");

        eCharsDataVo.setCount(3);
        eCharsDataVo.setData(list);
        list.forEach(s-> System.out.println(s));
        return eCharsDataVo;
    }

    @ApiOperation("获取柱状图")
    @CrossOrigin
    @GetMapping("/line")
    public DataVo<Integer> getPage(){
        //预约总人数
        int count = yuyueService.count();
        //预检总人数
        int count1 = yuejianService.count();
        //签到总人数
        int count2 = qiandaoService.count();
        //接种总人数
        int count3 = jiezhongService.count();
        //留观总人数
        int count4 = liuguanService.count();
//        EChars eChars = new EChars();
//        eChars.setYuyue(count);
//        eChars.setYujian(count1);
//        eChars.setJiezhong(count2);
        List<Integer> list=new ArrayList<>();
        list.add(count);
        list.add(count1);
        list.add(count2);
        list.add(count3);
        list.add(count4);

        DataVo<Integer> eCharsDataVo = new DataVo<>();
        eCharsDataVo.setCode(0);
        eCharsDataVo.setMsg("成功获取数据");

        eCharsDataVo.setCount(3);
        eCharsDataVo.setData(list);
        list.forEach(s-> System.out.println(s));
        return eCharsDataVo;
    }


    @ApiOperation("获取线形图")
    @CrossOrigin
    @RequestMapping("/lines")
    public Result<Map> getLinePage(){
        //List<List> allList = new ArrayList<>();
        Map<String,List> allMap = new HashMap<>();

        List dayListOfMonth =getNDaysList(null, DateUtils.dateStr2(DateUtils.getNow()), 15); //getDayListOfMonth();
//        getDays()
        //每月预约人数的集合
        List<Integer> yuyueList = new ArrayList<>();
        //每月签到人数的集合
        List<Integer> qiandaoList = new ArrayList<>();
        //每月预检人数的集合
        List<Integer> yujianList = new ArrayList<>();
        //每月接种人数的集合
        List<Integer> jiezhongList = new ArrayList<>();
        //每月留观人数的集合
        List<Integer> liugunaList = new ArrayList<>();

        System.out.println(dayListOfMonth);
        for (int i=0;i<dayListOfMonth.size();i++){
            String date = dayListOfMonth.get(i).toString();
            //预约每天的人数
            QueryWrapper<Yuyue> qw = new QueryWrapper<>();
            qw.eq("yuyueriqi",date);
            int count = yuyueService.count(qw);
            yuyueList.add(count);
            //签到每天的人数
            QueryWrapper<Qiandao> qwQiandao = new QueryWrapper<>();
            qwQiandao.between("qiandao",date+" 00:00:00",date+" 23.59.59");
            int count1 = qiandaoService.count(qwQiandao);
            qiandaoList.add(count1);
            //预检
            QueryWrapper<Yuejian> qwYujian = new QueryWrapper<>();
            qwYujian.between("create_time ",date+" 00:00:00",date+" 23.59.59");
            int count2 = yuejianService.count(qwYujian);
            yujianList.add(count2);
            //接种
            QueryWrapper<Jiezhong> qwjiezhong = new QueryWrapper<>();
            qwjiezhong.between("create_time ",date+" 00:00:00",date+" 23.59.59");
            int count3 = jiezhongService.count(qwjiezhong);
            jiezhongList.add(count3);
            //留观
            QueryWrapper<Liuguan> qwliuguan = new QueryWrapper<>();
            qwliuguan.between("create_time ",date+" 00:00:00",date+" 23.59.59");
            int count4 = liuguanService.count(qwliuguan);
            liugunaList.add(count4);

        }

        List dayListOfMonth1 = getNDaysList2(null, DateUtils.dateStr(DateUtils.getNow(),"MM-dd"), 15);
        allMap.put("date",dayListOfMonth1);
        allMap.put("yuyue",yuyueList);
        allMap.put("yujian",yujianList);
        allMap.put("qiandao",qiandaoList);
        allMap.put("jiezhong",jiezhongList);
        allMap.put("liuguan",liugunaList);

        return Result.ok(allMap);
    }

    /**

     * 获取当月所有天

     * @return

     */

    public static List getDayListOfMonth() {
        List list = new ArrayList();

        Calendar aCalendar = Calendar.getInstance(Locale.CHINA);

        int year = aCalendar.get(Calendar.YEAR);//年份

        int month = aCalendar.get(Calendar.MONTH) + 1;//月份

        int day = aCalendar.getActualMaximum(Calendar.DATE);

        for (int i = 1; i <= day; i++) {
            String aDate = String.valueOf(year)+"-"+month+"-"+i;

            list.add(aDate);

        }

        return list;

    }

    public static List<String> getDays(String startTime, String endTime) {

        // 返回的日期集合
        List<String> days = new ArrayList<String>();

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date start = dateFormat.parse(startTime);
            Date end = dateFormat.parse(endTime);

            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);

            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);// 日期加1(包含结束)
            while (tempStart.before(tempEnd)) {
                days.add(dateFormat.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return days;
    }

    /**
     *  用户可以传入startTime或endTime任意一个或两个，也可以不传入
     *  当传入的时间间隔太长时，默认返回最近的nday
     *  plus: StringUtils为org.apache.commons.lang.StringUtils，读者也可以手动判断""和null
     */
    public static List<String> getNDaysList(String startTime, String endTime, int nday) {
        int ndaycurrent = nday - 1;
        // 返回的日期集合
        List<String> days = new ArrayList<String>();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE,-ndaycurrent);
            Date start = calendar.getTime();
            Date end = new Date();
            if (StringUtils.isNotBlank(startTime) && StringUtils.isBlank(endTime)){
                //如果用户只选择了startTime,endTime为null,startTime + 10的日期
                start = dateFormat.parse(startTime);
                Calendar calendar1 = Calendar.getInstance();
                calendar1.setTime(start);
                calendar1.add(Calendar.DATE, ndaycurrent);
                end = calendar1.getTime();
            }else if(StringUtils.isBlank(startTime) && StringUtils.isNotBlank(endTime)){
                //如果用户只选择了endTime,startTime为null,endTime - 10的日期
                end = dateFormat.parse(endTime);
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTime(end);
                calendar2.add(Calendar.DATE, -ndaycurrent);
                start = calendar2.getTime();
            }else if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)){
                //如果用户选择了startTime和endTime，判断endTime - startTime两个日期是否超过了ndaycurrent，超过返回最近nday天记录
                Date start1 = dateFormat.parse(startTime);
                Date end1 = dateFormat.parse(endTime);
                int a = (int) ((end1.getTime() - start1.getTime()) / (1000*3600*24));
                if (a <= ndaycurrent) {
                    //如果小于等于n天
                    start = dateFormat.parse(startTime);
                    end = dateFormat.parse(endTime);
                }
            }
            //如果超过了ndaycurrent天,就是默认的start和end
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);

            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);// 日期加1(包含结束)

            while (tempStart.before(tempEnd)) {
                days.add(dateFormat.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return days;
    }

    /**
     *  用户可以传入startTime或endTime任意一个或两个，也可以不传入
     *  当传入的时间间隔太长时，默认返回最近的nday
     *  plus: StringUtils为org.apache.commons.lang.StringUtils，读者也可以手动判断""和null
     */
    public static List<String> getNDaysList2(String startTime, String endTime, int nday) {
        int ndaycurrent = nday - 1;
        // 返回的日期集合
        List<String> days = new ArrayList<String>();
        DateFormat dateFormat = new SimpleDateFormat("MM-dd");
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE,-ndaycurrent);
            Date start = calendar.getTime();
            Date end = new Date();
            if (StringUtils.isNotBlank(startTime) && StringUtils.isBlank(endTime)){
                //如果用户只选择了startTime,endTime为null,startTime + 10的日期
                start = dateFormat.parse(startTime);
                Calendar calendar1 = Calendar.getInstance();
                calendar1.setTime(start);
                calendar1.add(Calendar.DATE, ndaycurrent);
                end = calendar1.getTime();
            }else if(StringUtils.isBlank(startTime) && StringUtils.isNotBlank(endTime)){
                //如果用户只选择了endTime,startTime为null,endTime - 10的日期
                end = dateFormat.parse(endTime);
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTime(end);
                calendar2.add(Calendar.DATE, -ndaycurrent);
                start = calendar2.getTime();
            }else if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)){
                //如果用户选择了startTime和endTime，判断endTime - startTime两个日期是否超过了ndaycurrent，超过返回最近nday天记录
                Date start1 = dateFormat.parse(startTime);
                Date end1 = dateFormat.parse(endTime);
                int a = (int) ((end1.getTime() - start1.getTime()) / (1000*3600*24));
                if (a <= ndaycurrent) {
                    //如果小于等于n天
                    start = dateFormat.parse(startTime);
                    end = dateFormat.parse(endTime);
                }
            }
            //如果超过了ndaycurrent天,就是默认的start和end
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);

            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);// 日期加1(包含结束)

            while (tempStart.before(tempEnd)) {
                days.add(dateFormat.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return days;
    }

}
