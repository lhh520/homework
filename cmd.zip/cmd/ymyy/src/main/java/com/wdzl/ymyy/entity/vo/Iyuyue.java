package com.wdzl.ymyy.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Yuyue对象", description="预约记录")
public class Iyuyue {
    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "接种人")
    private String user;

    @ApiModelProperty(value = "接种地点名称")
    private String jiezhongdianName;

    @ApiModelProperty(value = "接种地点地址")
    private String jiezhongdianAddress;

    @ApiModelProperty(value = "预约日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone="GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // 用于将前端传过来的日期字符串自动转化为日期对象;
    private LocalDate yuyueriqi;

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "预约二维码地址")
    private String qrCodePath;
}
