package com.wdzl.ymyy.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>
 * 预约记录
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Yuyue对象", description="预约记录")
public class Yuyue implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "接种人")
    private Integer userId;

    @ApiModelProperty(value = "所属接种点")
    private Integer jiezhongdianId;

    @ApiModelProperty(value = "接种地点名称")
    private String jiezhongdianName;

    @ApiModelProperty(value = "接种地点地址")
    private String jiezhongdianAddress;

    @ApiModelProperty(value = "预约日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone="GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // 用于将前端传过来的日期字符串自动转化为日期对象;
    private LocalDate yuyueriqi;

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "预约二维码地址")
    private String qrCodePath;


}
