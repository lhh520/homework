package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.entity.vo.YujianVo;
import com.wdzl.ymyy.service.*;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 预检记录
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "预检记录相关数据接口")
@CrossOrigin
@RestController
@RequestMapping("/yuejian")
public class YuejianController {

    @Autowired
    private IYuejianService iYuejianService;

    @Autowired
    private IJiezhongService iJiezhongService;

    @Resource
    private UserService userService;

    @Resource
    private IJiezhongdianWorkerService jiezhongdianWorkerService;

    @Resource
    private IJiezhongdianService jiezhongdianService;

    @ApiOperation("分页获取疫苗记录的信息")
    @CrossOrigin
    @RequestMapping(value = "/pageQuery",method = {RequestMethod.POST,RequestMethod.GET})
    public DataVo<YujianVo> pageQuery(String username, Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<Yuejian> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<Yuejian> qw =new QueryWrapper<>();
//        if(createTime != null){
//            qw.eq("create_time",createTime);
//        }
        QueryWrapper<User> qw1 =new QueryWrapper<>();
        if (!StringUtils.isEmpty(username)){
            qw1.like("real_name", username);
            List<User> list = userService.list(qw1);
            list.forEach(s-> System.out.println());
            for (int i = 0; i < list.size(); i++) {
                qw.eq("jiezhongren", list.get(i).getId());
            }
        }
//
        districtPage = iYuejianService.page(districtPage,qw);

        List<Yuejian> records = districtPage.getRecords();

        List<YujianVo> yujianVos = new ArrayList<>();

        for (int i=0;i<records.size();i++){
            YujianVo yujianVo = new YujianVo();
            //id
            yujianVo.setId(records.get(i).getId());
            //接种人
            User byId = userService.getById(records.get(i).getJiezhongren());
            yujianVo.setJiezhongren(byId.getRealName());
            //是否服药
            if (records.get(i).getIsFuyao()==0){
                yujianVo.setIsFuyao("否");
            }else {
                yujianVo.setIsFuyao("是");
            }
            //高压
            yujianVo.setGaoya(records.get(i).getGaoya());
            //低压
            yujianVo.setDiya(records.get(i).getDiya());
            //体温
            yujianVo.setTiwen(records.get(i).getTiwen());
            //记录人
            JiezhongdianWorker byId1 = jiezhongdianWorkerService.getById(records.get(i).getCreator());
            yujianVo.setCreator(byId1.getRealName());
            //接种时间
            yujianVo.setCreateTime(records.get(i).getCreateTime());
            //接种点
            Jiezhongdian byId2 = jiezhongdianService.getById(records.get(i).getJiezhongdianId());
            yujianVo.setJiezhongdianId(byId2.getName()+byId2.getAddress());
            //预约ID
            yujianVo.setYuyueId(records.get(i).getYuyueId());
            yujianVos.add(yujianVo);

        }
        DataVo<YujianVo> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(yujianVos);
        return dataVo;
    }

    //    @ApiOperation("分页获取疫苗记录的信息")
    //    @CrossOrigin
    //    @RequestMapping(value = "/pageQuery",method = {RequestMethod.POST,RequestMethod.GET})
    //    public DataVo<Yuejian> pageQuery(LocalDateTime createTime, Integer page, Integer limit){
    //        if(page==null)page=1;
    //        if(limit==null)limit=10;
    //        Page<Yuejian> districtPage =new Page<>();
    //        districtPage.setSize(limit);
    //        districtPage.setCurrent(page);
    //        QueryWrapper<Yuejian> qw =new QueryWrapper<>();
    //        if(createTime != null){
    //            qw.eq("create_time",createTime);
    //        }
    ////        qw.orderByAsc("code");// 按照编码的升序显示；
    //        districtPage = iYuejianService.page(districtPage,qw);
    //        DataVo<Yuejian> dataVo =new DataVo<>();
    //        dataVo.setMsg("成功获取数据");
    //        dataVo.setCode(0);
    //        dataVo.setCount((int) districtPage.getTotal());
    //        dataVo.setData(districtPage.getRecords());
    //        return dataVo;
    //    }
}

