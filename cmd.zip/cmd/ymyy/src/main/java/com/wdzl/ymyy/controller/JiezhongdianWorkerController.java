package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.entity.vo.JiezhongdianWorkerVo;
import com.wdzl.ymyy.entity.vo.UserVo;
import com.wdzl.ymyy.service.DistrictService;
import com.wdzl.ymyy.service.IJiezhongdianService;
import com.wdzl.ymyy.service.IJiezhongdianWorkerService;
import com.wdzl.ymyy.service.UserService;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */

@Api(tags = "接种点工作人员相关接口")
@CrossOrigin
@RestController
@RequestMapping("/jiezhongdianWorker")
public class JiezhongdianWorkerController {

    @Autowired
    private IJiezhongdianWorkerService iJiezhongdianWorkerService;

    @Autowired
    private IJiezhongdianService jiezhongdianService;

    @Autowired
    private UserService userService;

    @Autowired
    private DistrictService districtService;

    @ApiOperation("分页获取接种点的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<JiezhongdianWorkerVo> pageQuery(String realName, Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<JiezhongdianWorker> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<JiezhongdianWorker> qw =new QueryWrapper<>();
        if (!StringUtils.isEmpty(realName)){
            qw.like("real_name",realName);
        }
        districtPage = iJiezhongdianWorkerService.page(districtPage,qw);

        List<JiezhongdianWorkerVo> jiezhongdianWorkerVos = new ArrayList<>();

        List<JiezhongdianWorker> records = districtPage.getRecords();
        for (int i=0;i<records.size();i++){
            JiezhongdianWorkerVo jiezhongdianWorkerVo = new JiezhongdianWorkerVo();
            //id
            jiezhongdianWorkerVo.setId(records.get(i).getId());
            //用户名
            jiezhongdianWorkerVo.setUsername(records.get(i).getUsername());
            //姓名
            jiezhongdianWorkerVo.setRealName(records.get(i).getRealName());
            //电话
            jiezhongdianWorkerVo.setPhone(records.get(i).getPhone());
            //身份证
            jiezhongdianWorkerVo.setCard(records.get(i).getCard());
            //地区
            Jiezhongdian byId = jiezhongdianService.getById(records.get(i).getJiezhongdianId());
            jiezhongdianWorkerVo.setJiezhongdianId(byId.getName());
            jiezhongdianWorkerVos.add(jiezhongdianWorkerVo);
        }
        DataVo<JiezhongdianWorkerVo> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(jiezhongdianWorkerVos);
        return dataVo;
    }


    /**
     * 添加工作人员方法
     * @param username 账户
     * @param realName 真实姓名
     * @param password 密码
     * @return 执行结果
     */
    //调用adminService
    @ApiOperation(value = "添加工作人员")
    @PostMapping("/save")
    @CrossOrigin
    public Result<JiezhongdianWorker> sava(String username, String realName, String password,
                       String phone, String card, Integer jiezhongdianId){

        JiezhongdianWorker jiezhongdianWorker = new JiezhongdianWorker();
        jiezhongdianWorker.setUsername(username);
        jiezhongdianWorker.setRealName(realName);
                jiezhongdianWorker.setPassword(password);
        jiezhongdianWorker.setPhone(phone);
                jiezhongdianWorker.setCard(card);
                jiezhongdianWorker.setJiezhongdianId(jiezhongdianId);

        //调用service
        try {
            boolean save = iJiezhongdianWorkerService.save(jiezhongdianWorker);
            return Result.ok("success");
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

    /**
     * 更新工作人员信息方法
     * 注意点：
     * 1.账号唯一
     * 2.密码长度2-12
     *
     * @param
     * @return 执行结果
     */
    @ApiOperation(value = "更新工作人员信息")
    @PostMapping("/update")
    @CrossOrigin
    public Result<JiezhongdianWorker> update(JiezhongdianWorker jiezhongdianWorker){


        //调用service
        try {
            boolean save = iJiezhongdianWorkerService.updateById(jiezhongdianWorker);
            return Result.ok("success");
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除工作人员
     * @param id 管理员id
     * @return 执行结果
     */
    @ApiOperation(value = "删除工作人员")
    @GetMapping("/delate")
    @CrossOrigin
    public Result delate(String id){
        //调用service
        try {
            int i = Integer.parseInt(id);
            boolean b = iJiezhongdianWorkerService.removeById(i);

            System.out.println(b);
            if (b){
                return Result.ok("success");
            }else {
                return Result.noAuth("no");
            }

        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

















    /**
     *分页查询
     * @param page 当前页码
     * @param limit 最大记录数
     * @return 分页结果
     */
    @ApiOperation(value = "分页获取所有用户")
    @RequestMapping(value = "/users/list",method = {RequestMethod.POST,RequestMethod.GET})
    @CrossOrigin
    public DataVo<UserVo> list(@RequestParam(required = false)String realName,
                               @RequestParam(defaultValue = "1") Integer page,
                               @RequestParam(defaultValue = "5") Integer limit){


        Page<User> p1 = new Page<>();
        p1.setCurrent(page);//当前页
        p1.setSize((long)limit);//每页最多条数
        QueryWrapper<User> qwUser = new QueryWrapper<>();


        if (!StringUtils.isEmpty(realName)){
            qwUser.like("real_name",realName);
        }

        ArrayList<UserVo> userVos = new ArrayList<>();
        Page<User> page1 = userService.page(p1,qwUser);
        List<User> records = page1.getRecords();
        for (int i=0;i<records.size();i++){
            UserVo userVo = new UserVo();
            //设置ID
            Long id = records.get(i).getId();
            int i1 = id.intValue();
            userVo.setId(i1);

            //设置
            userVo.setUsername(records.get(i).getUsername());
            //姓名
            userVo.setRealName(records.get(i).getRealName());
            //电话
            userVo.setPhone(records.get(i).getPhone());
            //密码
            userVo.setPassword(records.get(i).getPassword());
            //身份证
            userVo.setCard(records.get(i).getCard());
            //地区
            QueryWrapper<District> districtQueryWrapper = new QueryWrapper<>();
            districtQueryWrapper.eq("code",records.get(i).getArea());
            District one = districtService.getOne(districtQueryWrapper);

            userVo.setArea(one.getName());
            //地址
            userVo.setAddress(records.get(i).getAddress());

                userVos.add(userVo);

        }




        DataVo<UserVo> dataVo=new DataVo();
        dataVo.setCode(0);
        dataVo.setMsg("成功");
        dataVo.setCount((int)page1.getTotal());
        dataVo.setData(userVos);
        // Result.ok(page1.getRecords()).setCode(0);

        return dataVo;
    }
    ///////////
    @ApiOperation(value = "添加用户")
    @PostMapping("/users/save")
    @CrossOrigin
    public String sava1(User user){
        



        //调用service
        try {
            boolean save = userService.save(user);
            return "ok";
        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }

    /**
     * 更新用户信息方法
     * 注意点：
     * 1.账号唯一
     * 2.密码长度2-12
     *
     * @param admin
     * @return 执行结果
     */
    @ApiOperation(value = "更新用户信息")
    @PostMapping("/users/update")
    @CrossOrigin
    public String update1(User admin){


        //调用service
        try {
            boolean save = userService.updateById(admin);
            return "ok";
        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }
    /**
     * 删除用户
     * @param id 用户id
     * @return 执行结果
     */
    @ApiOperation(value = "删除用户")
    @GetMapping("/users/delate")
    @CrossOrigin
    public String delate1(int id){
        //调用service
        try {
            boolean b = userService.removeById(id);
            System.out.println(b);
            if (b){
                return "ok";
            }else {
                return "no";
            }

        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }

}

