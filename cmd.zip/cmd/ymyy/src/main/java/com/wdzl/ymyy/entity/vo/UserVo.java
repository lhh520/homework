package com.wdzl.ymyy.entity.vo;

import lombok.Data;

@Data
public class UserVo {
    private Integer id;
    private String username;
    private String realName;
    private String password;
    private String phone;
    private String card;
    private String area;
    private String address;


}
