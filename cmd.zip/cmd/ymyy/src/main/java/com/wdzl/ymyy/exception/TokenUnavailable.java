package com.wdzl.ymyy.exception;

public class TokenUnavailable extends Exception {
}
