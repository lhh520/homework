package com.wdzl.ymyy.config;

import com.wdzl.ymyy.interceptor.WorkerJwtAuthInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author dwk
 */
@Configuration
public class WorkerJwtInterceptorConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        //默认拦截所有路径
        //注册TestInterceptor拦截器
        InterceptorRegistration registration = registry.addInterceptor(workerJwtAuthInterceptor());
        registration.addPathPatterns("/worker/**");
        registration.excludePathPatterns(                         //添加不拦截路径
                "/worker/login",            //登录
                "/worker/logout"           // 获取轮播图

        );
    }
    @Bean
    public WorkerJwtAuthInterceptor workerJwtAuthInterceptor() {
        return new WorkerJwtAuthInterceptor();
    }
}
