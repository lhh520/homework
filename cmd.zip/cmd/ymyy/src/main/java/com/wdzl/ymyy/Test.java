package com.wdzl.ymyy;

import com.alibaba.fastjson.JSONObject;
import com.wdzl.ymyy.entity.Yuyue;
import com.wdzl.ymyy.utils.Global;
import com.wdzl.ymyy.utils.QRCodeUtil;

import javax.xml.bind.SchemaOutputResolver;
import java.io.File;
import java.time.LocalDate;
import java.util.UUID;

public class Test {
    static void  m1() throws Exception {
        Yuyue y =new Yuyue();
        y.setId(1);
        y.setStatus(0);
        y.setQrCodePath("\\dwk_qr\\001.png");
        y.setUserId(2);
        y.setJiezhongdianId(1);
        y.setYuyueriqi(LocalDate.now());
        y.setJiezhongdianAddress("小寨西路100号");
        y.setJiezhongdianName("长延堡社区卫生服务中心");
        System.out.println(JSONObject.toJSONString(y));
        File file = new File (Global.getImgDirFile(), UUID.randomUUID().toString()+".png");
        String imgpath =  QRCodeUtil.generateQRCode(JSONObject.toJSONString(y) + "", 400, 400, "png", file.getPath());
        y.setQrCodePath(imgpath.replace("\\","/"));
        System.out.println(y.getQrCodePath());
    }
    public static void main(String[] args) throws Exception {


        LocalDate yyrq = LocalDate.of(2021,07,18);
        LocalDate localDate = LocalDate.now();
        int value = localDate.compareTo(yyrq);
        System.out.println(value);
        if(value>0){
            throw new RuntimeException("预约已过期");
        }
        if(value<0){

            throw new RuntimeException("预约日期还未到");
        }
    }
}
