package com.wdzl.ymyy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wdzl.ymyy.entity.Admin;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor = Exception.class)
public interface AdminService extends IService<Admin> {

    public Admin findByUsername(String username);
}
