package com.wdzl.ymyy.config;

import com.wdzl.ymyy.interceptor.AdminJwtAuthInterceptor;
import com.wdzl.ymyy.interceptor.JiezhongzheJwtAuthInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 *
 * @author dwk
 */
@Configuration
public class AdminJwtInterceptorConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        //默认拦截所有路径
        //注册TestInterceptor拦截器
        InterceptorRegistration registration = registry.addInterceptor(adminJwtAuthInterceptor());
        registration.addPathPatterns("/admin/**");
        registration.excludePathPatterns(                         //添加不拦截路径
                "/admin/login"
                ,"/admin/logout"

        );
    }
    @Bean
    public AdminJwtAuthInterceptor adminJwtAuthInterceptor() {
        return new AdminJwtAuthInterceptor();
    }
}
