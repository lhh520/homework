package com.wdzl.ymyy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wdzl.ymyy.entity.Admin;

public interface AdminMapper extends BaseMapper<Admin> {
}
