package com.wdzl.ymyy.mapper;

import com.wdzl.ymyy.entity.Address;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2023-03-15
 */
public interface AddressMapper extends BaseMapper<Address> {

}
