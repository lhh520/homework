package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.DataVo;
import com.wdzl.ymyy.entity.District;
import com.wdzl.ymyy.entity.Jiezhong;
import com.wdzl.ymyy.entity.User;
import com.wdzl.ymyy.entity.vo.Ijiezhong;
import com.wdzl.ymyy.service.IJiezhongService;
import com.wdzl.ymyy.service.IJiezhongdianService;
import com.wdzl.ymyy.service.IJiezhongdianWorkerService;
import com.wdzl.ymyy.service.UserService;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "接种相关接口")
@CrossOrigin
@RestController
@RequestMapping("/jiezhong")
public class JiezhongController {

    @Autowired
    private IJiezhongService iJiezhongService;

    @Resource
    private UserService userService;

    @Resource
    private IJiezhongdianWorkerService jiezhongdianWorkerService;

    @Resource
    private IJiezhongdianService jiezhongdianService;

    @ApiOperation("分页获取接种记录的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<Ijiezhong> pageQuery(Integer page, Integer limit,String username){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<Jiezhong> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<Jiezhong> qw =new QueryWrapper<>();
//        qw.orderByAsc("code");// 按照编码的升序显示；
        QueryWrapper<User> qw1 =new QueryWrapper<>();
        if (!StringUtils.isEmpty(username)) {
            qw1.like("real_name", username);
            List<User> list = userService.list(qw1);
            for (int i = 0; i < list.size(); i++) {
                qw.eq("jiezhongren", list.get(i).getId());
            }
        }
        districtPage = iJiezhongService.page(districtPage,qw);
        List<Jiezhong> records = districtPage.getRecords();
        List<Ijiezhong> ijiezhongs = new ArrayList<>();
        for (int i=0;i<records.size();i++){
            Ijiezhong ijiezhong = new Ijiezhong();
            ijiezhong.setId(records.get(i).getId());
            ijiezhong.setJiezhongren(userService.getById(records.get(i).getJiezhongren()).getRealName());
            ijiezhong.setJiezhongbuwei(records.get(i).getJiezhongbuwei());
            ijiezhong.setYimiaoId(records.get(i).getYimiaoId());
            ijiezhong.setYimiaoZhonglei(records.get(i).getYimiaoZhonglei());
            ijiezhong.setYimiaoShengchanqiye(records.get(i).getYimiaoShengchanqiye());
            ijiezhong.setChengjishu(records.get(i).getChengjishu());
            ijiezhong.setYimiaoPihao(records.get(i).getYimiaoPihao());
            ijiezhong.setCreator(jiezhongdianWorkerService.getById(records.get(i).getCreator()).getRealName());
            ijiezhong.setCreateTime(records.get(i).getCreateTime());
            ijiezhong.setJiezhongdian(jiezhongdianService.getById(records.get(i).getJiezhongdianId()).getName());
            ijiezhong.setYuyueId(records.get(i).getYuyueId());
            ijiezhongs.add(ijiezhong);
        }



        DataVo<Ijiezhong> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(ijiezhongs);
        return dataVo;
    }


//    @ApiOperation("分页获取接种记录的信息")
//    @CrossOrigin
//    @GetMapping("/pageQuery")
//    public DataVo<Jiezhong> pageQuery(Integer page, Integer limit){
//        if(page==null)page=1;
//        if(limit==null)limit=10;
//        Page<Jiezhong> districtPage =new Page<>();
//        districtPage.setSize(limit);
//        districtPage.setCurrent(page);
//        QueryWrapper<Jiezhong> qw =new QueryWrapper<>();
////        qw.orderByAsc("code");// 按照编码的升序显示；
//        districtPage = iJiezhongService.page(districtPage,qw);
//        DataVo<Jiezhong> dataVo =new DataVo<>();
//        dataVo.setMsg("成功获取数据");
//        dataVo.setCode(0);
//        dataVo.setCount((int) districtPage.getTotal());
//        dataVo.setData(districtPage.getRecords());
//        return dataVo;
//    }


}

