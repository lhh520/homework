package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.entity.vo.QiandaoVo;
import com.wdzl.ymyy.service.*;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "签到记录相关接口")
@CrossOrigin
@RestController
@RequestMapping("/qiandao")
public class QiandaoController {

    @Autowired
    private IQiandaoService iQiandaoService;

    @Autowired
    private IYuyueService iYuyueService;

    @Autowired
    private UserService userService;

    @Autowired
    private IJiezhongdianService jiezhongdianService;

    @Autowired
    private IJiezhongdianWorkerService jiezhongdianWorkerService;

    @ApiOperation("分页获取签到记录的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<QiandaoVo> pageQuery(String qiandaoren,Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<Qiandao> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<Qiandao> qw =new QueryWrapper<>();
        if (!StringUtils.isEmpty(qiandaoren)){
            QueryWrapper<User> qwUser = new QueryWrapper<User>();
            qwUser.like("real_name",qiandaoren);

            List<User> list = userService.list(qwUser);
            for (int i=0;i<list.size();i++){
                qw.eq("qiandaoren",list.get(i).getId());
            }
        }

        List<QiandaoVo> qiandaoVos = new ArrayList<>();
        districtPage = iQiandaoService.page(districtPage,qw);
        List<Qiandao> records = districtPage.getRecords();
        for (int i=0;i<records.size();i++){
            QiandaoVo qiandaoVo = new QiandaoVo();
            //id
            qiandaoVo.setId(records.get(i).getId());
            //签到人，（接种者）
            User byId = userService.getById(records.get(i).getQiandaoren());
            qiandaoVo.setQiandaoren(byId.getRealName());
            //签到日期
            qiandaoVo.setQiandao(records.get(i).getQiandao());
            //记录人
            JiezhongdianWorker byId1 = jiezhongdianWorkerService.getById(records.get(i).getCreator());
            qiandaoVo.setCreator(byId1.getRealName());
            //接种点
            Jiezhongdian byId2 = jiezhongdianService.getById(records.get(i).getDiezhongdianId());
            qiandaoVo.setDiezhongdianId(byId2.getName()+byId2.getAddress());

            //预约号
            qiandaoVo.setYuyueId(records.get(i).getYuyueId());
            qiandaoVos.add(qiandaoVo);
        }


//        qw.orderByAsc("code");// 按照编码的升序显示；

        DataVo<QiandaoVo> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(qiandaoVos);
        return dataVo;
    }

    //    @ApiOperation("分页获取签到记录的信息")
    //    @CrossOrigin
    //    @GetMapping("/pageQuery")
    //    public DataVo<Qiandao> pageQuery(Integer page, Integer limit){
    //        if(page==null)page=1;
    //        if(limit==null)limit=10;
    //        Page<Qiandao> districtPage =new Page<>();
    //        districtPage.setSize(limit);
    //        districtPage.setCurrent(page);
    //        QueryWrapper<Qiandao> qw =new QueryWrapper<>();
    ////        qw.orderByAsc("code");// 按照编码的升序显示；
    //        districtPage = iQiandaoService.page(districtPage,qw);
    //        DataVo<Qiandao> dataVo =new DataVo<>();
    //        dataVo.setMsg("成功获取数据");
    //        dataVo.setCode(0);
    //        dataVo.setCount((int) districtPage.getTotal());
    //        dataVo.setData(districtPage.getRecords());
    //        return dataVo;
    //    }
}

