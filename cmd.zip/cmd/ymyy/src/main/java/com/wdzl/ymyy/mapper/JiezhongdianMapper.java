package com.wdzl.ymyy.mapper;

import com.wdzl.ymyy.entity.Jiezhongdian;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 接种点信息 Mapper 接口
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface JiezhongdianMapper extends BaseMapper<Jiezhongdian> {

    @Select("SELECT a.*," +
            "(SELECT b.name FROM t_dict_district b WHERE b.code = a.sheng) AS shengName  ," +
            "(SELECT b.name FROM t_dict_district b WHERE b.code = a.shi) AS shiName  ," +
            "(SELECT b.name FROM t_dict_district b WHERE b.code = a.qu) AS quName " +
            "FROM jiezhongdian a")
    public List<Map<String,Object>> findAll();
}
