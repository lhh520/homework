package com.wdzl.ymyy.entity.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class QiandaoVo {
    private Integer id;
    private String qiandaoren;
    private LocalDateTime qiandao;
    private String creator;
    private String diezhongdianId;
    private Integer yuyueId;

}
