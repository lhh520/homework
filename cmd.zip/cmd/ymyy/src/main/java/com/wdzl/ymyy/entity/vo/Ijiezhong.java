package com.wdzl.ymyy.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Ijiezhong {

    private Integer id;

    private String jiezhongren;

    private String jiezhongbuwei;

    private Integer yimiaoId;

    private String yimiaoZhonglei;

    private String yimiaoShengchanqiye;

    private Integer chengjishu;

    private String yimiaoPihao;

    private String creator;

    private LocalDateTime createTime;

    private String jiezhongdian;

    private Integer yuyueId;



}
