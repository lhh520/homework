package com.wdzl.ymyy.entity;

import lombok.Data;

import java.util.List;

@Data
public class DataVo<T> {

    private Integer code=0;
    private String msg;
    private Integer count=0;
    private List<T> data;
}
