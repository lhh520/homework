package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.annotation.PassToken;
import com.wdzl.ymyy.entity.DataVo;
import com.wdzl.ymyy.entity.District;
import com.wdzl.ymyy.service.DistrictService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;


@Api(tags = "行政区划相关接口")
@RestController
@CrossOrigin
@RequestMapping("/district")
public class DistrictController {

    @Resource
    private DistrictService districtService;

    @ApiOperation("分页获取行政区划的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<District> pageQuery(Integer page,Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<District> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<District> qw =new QueryWrapper<>();
        qw.orderByAsc("code");// 按照编码的升序显示；
        districtPage = districtService.page(districtPage,qw);
        DataVo<District> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(districtPage.getRecords());
        return dataVo;
    }

    @ApiOperation("获取所有省份信息")
    @GetMapping("/findSheng")
    @PassToken
    public Result findSheng(){

        return Result.ok(districtService.findSheng());
    }

    @ApiOperation("获取某省份下的所有市信息")
    @PassToken
    @GetMapping("/findShi/{code}")
    public Result findShi(@PathVariable String code){

        return Result.ok(districtService.findShi(code));
    }

    @ApiOperation("获取某市下的所有县（街办）")
    @PassToken
    @GetMapping("/findQu/{code}")
    public Result findQu(@PathVariable String code){

        return Result.ok(districtService.findQu(code));
    }

}
