package com.wdzl.ymyy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.entity.Yimiao;
import com.wdzl.ymyy.entity.YimiaoLishi;
import com.wdzl.ymyy.mapper.YimiaoLishiMapper;
import com.wdzl.ymyy.mapper.YimiaoMapper;
import com.wdzl.ymyy.service.IYimiaoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
@Transactional
public class YimiaoServiceImpl extends ServiceImpl<YimiaoMapper, Yimiao> implements IYimiaoService {

    @Resource
    private YimiaoLishiMapper yimiaoLishiMapper;

    @Override
    public boolean updateById(Yimiao entity) {
// 疫苗名称不能重复
        String zl = entity.getYimiaoZhonglei();
        QueryWrapper<Yimiao> qw =new QueryWrapper<>();
        qw.eq("yimiao_zhonglei",zl);
        List<Yimiao> list = baseMapper.selectList(qw);
        if(list.size() ==1 ){
            Yimiao old =list.get(0);
            if(old.getId().intValue()!=entity.getId())
                throw new RuntimeException("系统已经存在相同种类名称的疫苗");
        }else if(list.size()>1){
            throw new RuntimeException("系统存在多个名称相同的疫苗");
        }
        return baseMapper.updateById(entity)==1;
    }

    @Override
    public boolean removeById(Serializable id) {
        QueryWrapper<YimiaoLishi> qw =new QueryWrapper();
        qw.eq("yimiao_id",id);
        if(yimiaoLishiMapper.selectCount(qw)>0){
            throw new RuntimeException("该疫苗信息已经被使用，不能删除");
        }
        return baseMapper.deleteById(id)==1;
    }

    @Override
    public boolean save(Yimiao entity){
        // 疫苗名称不能重复
        String zl = entity.getYimiaoZhonglei();
        QueryWrapper<Yimiao> qw =new QueryWrapper<>();
        qw.eq("yimiao_zhonglei",zl);
        if(baseMapper.selectCount(qw)>0){
            throw new RuntimeException("系统已经存在相同种类名称的疫苗");
        }
       return  baseMapper.insert(entity)==1;
    }
}
