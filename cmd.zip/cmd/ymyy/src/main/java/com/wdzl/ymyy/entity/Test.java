package com.wdzl.ymyy.entity;

import lombok.Data;

@Data
public class Test {
    private Integer id;
    private String name;
}
