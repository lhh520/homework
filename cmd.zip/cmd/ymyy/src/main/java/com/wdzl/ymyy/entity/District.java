package com.wdzl.ymyy.entity;


import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("t_dict_district")
public class District implements Serializable {

    private Integer id;
    private Integer parent;
    private String code;
    private String name;// 名称
}
