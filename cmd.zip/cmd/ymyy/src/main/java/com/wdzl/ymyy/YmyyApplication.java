package com.wdzl.ymyy;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.wdzl.ymyy.mapper")
public class YmyyApplication {
    public static void main(String[] args) {
        SpringApplication.run(YmyyApplication.class, args);
    }

}
