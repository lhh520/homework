package com.wdzl.ymyy.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.AdminQuery;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.annotation.PassToken;
import com.wdzl.ymyy.entity.Admin;
import com.wdzl.ymyy.entity.DataVo;
import com.wdzl.ymyy.entity.User;
import com.wdzl.ymyy.service.AdminService;
import com.wdzl.ymyy.service.UserService;
import com.wdzl.ymyy.utils.JwtUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.util.StringUtils;

import javax.annotation.Resource;
import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;


@CrossOrigin
@Api(tags="系统管理员相关接口")
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Resource
    private AdminService adminService;

    @Autowired
    private UserService userService;


    @ApiOperation("分页查询系统管理员信息")
    @PassToken
    @CrossOrigin
    @RequestMapping(value = "/pageQueryAdmin",method = {RequestMethod.POST,RequestMethod.GET})
    public DataVo<Admin> pageQueryAdmin(String realName , Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=1;
        System.out.println(realName);
        Page<Admin> userPage =new Page<>();
        userPage.setCurrent(page);
        userPage.setSize(limit);
        QueryWrapper<Admin> qw =new QueryWrapper<>();
        if(org.apache.commons.lang3.StringUtils.isNotEmpty(realName))
            qw.like("real_name",realName);
        userPage = adminService.page(userPage,qw);
        DataVo<Admin> dv =new DataVo<>();
        dv.setCode(0);
        dv.setCount((int) userPage.getTotal());
        dv.setData(userPage.getRecords());
        dv.setMsg("获取数据成功");

        return dv;

    }

    @ApiOperation("分页查询用户信息")
    @PassToken
    @RequestMapping(value = "/pageQueryUser",method = {RequestMethod.POST,RequestMethod.GET})
    public DataVo<User> pageQueryUser(String username , Integer page, Integer limit){
        System.out.println(username);
        Page<User> userPage =new Page<>();
        userPage.setCurrent(page);
        userPage.setSize(limit);
        QueryWrapper<User> qw =new QueryWrapper<>();
        if(org.apache.commons.lang3.StringUtils.isNotEmpty(username))
            qw.eq("username",username);
        userPage = userService.page(userPage,qw);
        DataVo<User> dv =new DataVo<>();
        dv.setCode(0);
        dv.setCount((int) userPage.getTotal());
        dv.setData(userPage.getRecords());
        dv.setMsg("获取数据成功");

        return dv;

    }


    @ApiOperation("分页查询用户信息")
    @PassToken
    @RequestMapping(value = "/queryUser",method = {RequestMethod.POST,RequestMethod.GET})
    public Result<User> queryUser(String id){

        User byId = userService.getById(id);


        return Result.ok(byId);

    }

    // 接种人员登录
    @PassToken
    @CrossOrigin

    @ApiOperation("系统官员用户登录")
    @RequestMapping(value = "/login",method = {RequestMethod.POST})
    public Result login(@RequestBody UsernameAndPw up){
        try{
            if(StringUtils.isEmpty(up.getUsername())){
                throw new RuntimeException("用户名不能为空");
            }
            if(StringUtils.isEmpty(up.getPassword())){
                throw new RuntimeException("密码不能为空");
            }
            QueryWrapper<Admin> qw =new QueryWrapper<>();
            qw.eq("username",up.getUsername());
            //List<Admin> list = adminService.list(qw);
            List<Admin> list =new ArrayList<>();
            Admin admin=adminService.findByUsername(up.getUsername());
            list.add(admin);
            System.out.println(admin.toString());
            if(list.size()>1){
                return Result.error("存在多个用户");
            }else if(list.size()==0){
                return Result.error("查无此用户");
            }else{
                // 查到用户
                Admin loginUser = list.get(0);
                if(!up.getPassword().equals(loginUser.getPassword())){
                    return Result.error("密码错误");
                }else{
                    loginUser.setPassword(null);
                    JSONObject obj =new JSONObject();
                    obj.put("loginUser",loginUser);
                    obj.put("userType","admin");
                    obj.put("token", JwtUtils.createToken(loginUser.getId()+"",loginUser.getUsername(),loginUser.getRealName(),"admin"));
                    return Result.ok(obj);
                }
            }
        }catch (Exception e){
            return Result.error("登录失败");
        }
    }

    @ApiOperation("系统官员用户登录")
    @GetMapping("/get/{id}")
    public Result get(@PathVariable Long id){
        return Result.ok(adminService.getById(id));
    }

    // 登录（不验证）
    @CrossOrigin(origins = "*")
    @PassToken(required = true)
    @RequestMapping(value = "/validate", method = RequestMethod.POST)
    public Result validate(@RequestBody UserToken userToken) {
        System.out.println(">>>" + userToken);
        try {
            // 获取 token 中的 user Name
            String userType = JwtUtils.getClaimByName(userToken.getToken(),"userType").asString();
            if(!userToken.getUserType().equals(userType)){
                throw new RuntimeException("用户的身份不符");
            }
            String userId = JwtUtils.getAudience(userToken.getToken());
            System.out.println(">>>" + userId);
            JwtUtils.verifyToken(userToken.getToken(), userId);
            return Result.ok("验证成功");
        } catch (Exception e) {
            Result result = Result.error("验证失败");
            result.setCode(510);
            return result;
        }

    }
    /**
     * 添加管理员方法
     * @param username 账户
     * @param realName 真实姓名
     * @param password 密码
     * @return 执行结果
     */
    //调用adminService
    @ApiOperation(value = "添加管理员")
    @PostMapping("/admin/save")
    @CrossOrigin
    @PassToken
    public String sava(String username,String realName,String password){

        Admin admin = new Admin();
        admin.setUsername(username);
        admin.setRealName(realName);
        admin.setPassword(password);

        //调用service
        try {
            boolean save = adminService.save(admin);
            return "ok";
        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }

    /**
     * 更新管理员信息方法
     * 注意点：
     * 1.账号唯一
     * 2.密码长度2-12
     *
     * @param admin
     * @return 执行结果
     */
    @ApiOperation(value = "更新管理员信息")
    @PostMapping("/admin/update")
    @CrossOrigin
    @PassToken
    public String update(Admin admin){


        //调用service
        try {
            boolean save = adminService.updateById(admin);
            return "ok";
        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }

    /**
     *分页查询
     * @param page 当前页码
     * @param limit 最大记录数
     * @return 分页结果
     */
    @ApiOperation(value = "条件查询分页获取所有管理员")
    @PostMapping("/admin/listPage")
    @CrossOrigin
    public DataVo listPage(@RequestParam(defaultValue = "1") Integer page,
                           @RequestParam(defaultValue = "3") Integer limit,
                           @RequestBody(required = false) AdminQuery adminQuery){
        QueryWrapper<Admin> qw = new QueryWrapper<>();
        String id = adminQuery.getId();
        String realName = adminQuery.getRealName();
        String username = adminQuery.getUsername();
        if (!StringUtils.isEmpty(id)){
            qw.like("id",id);
        }
        if (!StringUtils.isEmpty(realName)){
            qw.like("real_name",realName);
        }
        if (!StringUtils.isEmpty(username)){
            qw.like("username",username);
        }

        Page<Admin> p1 = new Page<>();
        p1.setCurrent(page);//当前页
        p1.setSize((long)limit);//每页最多条数
        Page<Admin> page1 = adminService.page(p1,qw);
        System.out.println(page1.getRecords());
        DataVo dataVo=new DataVo();
        dataVo.setMsg("成功");
        dataVo.setCount((int)page1.getTotal());
        dataVo.setData(page1.getRecords());
        return dataVo;
    }

    /**
     * 删除管理员
     * @param id 管理员id
     * @return 执行结果
     */
    @ApiOperation(value = "删除管理员")
    @GetMapping("/admin/delate")
    @CrossOrigin
    @PassToken
    public String delate(int id){
        //调用service
        try {
            boolean b = adminService.removeById(id);
            System.out.println(b);
            if (b){
                return "ok";
            }else {
                return "no";
            }

        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }




}
