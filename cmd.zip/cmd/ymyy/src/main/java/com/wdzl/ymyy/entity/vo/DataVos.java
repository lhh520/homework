package com.wdzl.ymyy.entity.vo;

import lombok.Data;

import java.util.List;
import java.util.Map;

public class DataVos {
    @Data
    public class DataVo<T> {

        private Integer code=0;
        private String msg;
        private Integer count=0;
        private Map<String,T> data;
    }

}
