package com.wdzl.ymyy.service;

import com.wdzl.ymyy.entity.Qiandao;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface IQiandaoService extends IService<Qiandao> {

    void qiandao(Qiandao qiandao);
}
