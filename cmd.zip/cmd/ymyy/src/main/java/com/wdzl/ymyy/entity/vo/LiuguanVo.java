package com.wdzl.ymyy.entity.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class LiuguanVo {
    private Integer id;
    private String jiezhongren;
    private Integer liiuguanShichang;
    private String liuguanShuoming;
    private String creator;
    private LocalDateTime createTime;
    private String jiezhongdianId;
    private Integer yuyueId;
}
