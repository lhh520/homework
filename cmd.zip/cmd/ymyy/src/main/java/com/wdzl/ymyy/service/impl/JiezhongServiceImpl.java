package com.wdzl.ymyy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.mapper.*;
import com.wdzl.ymyy.service.IJiezhongService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class JiezhongServiceImpl extends ServiceImpl<JiezhongMapper, Jiezhong> implements IJiezhongService {

    @Autowired
    private YuyueMapper yuyueMapper;
    @Autowired
    private YimiaoLishiMapper yimiaoLishiMapper;
    @Autowired
    private YimiaoMapper yimiaoMapper;
    @Autowired
    private JiezhongdianWorkerMapper jiezhongdianWorkerMapper;

    @Override
    public void jiezhong(Jiezhong jiezhong){
         // 验证疫苗预约地址，与接种地址是否相符
        JiezhongdianWorker worker = jiezhongdianWorkerMapper.selectById(jiezhong.getCreator());
        jiezhong.setJiezhongdianId(worker.getJiezhongdianId());
        Yuyue yuyue = yuyueMapper.selectById(jiezhong.getYuyueId());
        if(yuyue.getJiezhongdianId().longValue() != worker.getJiezhongdianId().longValue()){
            throw  new RuntimeException("预约地点与接种地点不一致");
        }
        jiezhong.setJiezhongren(yuyue.getUserId());

        Integer jiezhongren = jiezhong.getJiezhongren();
        Integer yimiaoId = jiezhong.getYimiaoId();
        // 写入疫苗接种历史
        Yimiao ym = yimiaoMapper.selectById(yimiaoId);

        jiezhong.setYimiaoShengchanqiye(ym.getYimiaoShengchanqiye());
        jiezhong.setYimiaoZhonglei(ym.getYimiaoZhonglei());

        QueryWrapper<YimiaoLishi> qw = new QueryWrapper<>();
        qw.eq("yimiao_id",yimiaoId);
        qw.eq("jiezhongren_id",jiezhongren);
        List<YimiaoLishi> list = yimiaoLishiMapper.selectList(qw);
        if(list.size()==0){
            jiezhong.setChengjishu(1);
            YimiaoLishi ls=new YimiaoLishi();
            ls.setFirstTime(jiezhong.getCreateTime());
            ls.setUpdateTime(jiezhong.getCreateTime());
            ls.setJiezhongrenId(jiezhong.getJiezhongren());
            ls.setYimiaoId(ym.getId());
            ls.setYidazhenshu(1);// 已打针数
            ls.setYimiaoZhonglei(ym.getYimiaoZhonglei());
            ls.setYimiaoShengchanqiye(ym.getYimiaoShengchanqiye());
            ls.setZhenshu(ym.getZhenshu());
            yimiaoLishiMapper.insert(ls);

        }else if(list.size()==1){
            YimiaoLishi yimiaoLishi = list.get(0);
            if(yimiaoLishi.getYidazhenshu()+1<=yimiaoLishi.getZhenshu()){
                yimiaoLishi.setYidazhenshu(yimiaoLishi.getYidazhenshu()+1);
                yimiaoLishi.setUpdateTime(jiezhong.getCreateTime());
                yimiaoLishiMapper.updateById(yimiaoLishi);
                jiezhong.setChengjishu(yimiaoLishi.getYidazhenshu()+1);
            }else{
                throw new RuntimeException("超出最大针剂数");
            }
        }else{
            throw new RuntimeException("数据出错！！");
        }
        save(jiezhong);

//        Long yyId = jiezhong.getYuyueId();
//        Yuyue yuyue = yuyueMapper.selectById(yyId);
//        yuyue.setStatus(1);
//        yuyueMapper.updateById(yuyue);

    }


}
