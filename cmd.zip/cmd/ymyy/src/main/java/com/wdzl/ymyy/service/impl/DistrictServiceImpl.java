package com.wdzl.ymyy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wdzl.ymyy.entity.District;
import com.wdzl.ymyy.mapper.DistrictMapper;
import com.wdzl.ymyy.service.DistrictService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DistrictServiceImpl extends ServiceImpl<DistrictMapper, District> implements DistrictService {
    @Override
    public List<District> findSheng() {
        QueryWrapper<District> qw =new QueryWrapper<>();
        qw.eq("parent","86");
        qw.orderByAsc("code");
        return getBaseMapper().selectList(qw);
    }

    @Override
    public List<District> findShi(String code) {
        QueryWrapper<District> qw =new QueryWrapper<>();
        qw.eq("parent",code);
        qw.orderByAsc("code");
        return getBaseMapper().selectList(qw);
    }

    @Override
    public List<District> findQu(String code) {
        QueryWrapper<District> qw =new QueryWrapper<>();
        qw.eq("parent",code);
        qw.orderByAsc("code");
        return getBaseMapper().selectList(qw);
    }
}
