package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.District;
import com.wdzl.ymyy.service.DistrictService;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.annotation.PassToken;
import com.wdzl.ymyy.entity.DataVo;
import com.wdzl.ymyy.entity.Jiezhongdian;
import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.service.IJiezhongdianService;
import com.wdzl.ymyy.service.IJiezhongdianWorkerService;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 接种点信息 前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "接种点相关接口")
@CrossOrigin
@RestController
@RequestMapping("/jiezhongdian")
public class JiezhongdianController {

    @Autowired
    private IJiezhongdianService iJiezhongdianService;

    @Autowired
    private IJiezhongdianWorkerService iJiezhongdianWorkerService;

    @Autowired
    private DistrictService districtService;



    @ApiOperation("分页获取接种点的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<Jiezhongdian> pageQuery(String name,Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<Jiezhongdian> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);

        QueryWrapper<Jiezhongdian> qw =new QueryWrapper<>();
        if (!StringUtils.isEmpty(name)){
                qw.like("name",name);
        }
        districtPage = iJiezhongdianService.page(districtPage,qw);
        List<Jiezhongdian> records = districtPage.getRecords();
        for (int i=0;i<records.size();i++){

            //获得省的信息，封装
            String sheng = records.get(i).getSheng();
            QueryWrapper<District> qqw = new QueryWrapper<>();
            qqw.eq("code",sheng);
            District one = districtService.getOne(qqw);
            records.get(i).setSheng(one.getName());
            //获得市的信息，封装
            String shi = records.get(i).getShi();
            QueryWrapper<District> qqqw = new QueryWrapper<>();
            qqqw.eq("code",shi);
            District one1 = districtService.getOne(qqqw);
            records.get(i).setShi(one1.getName());
            //获得区的信息，封装
            String qu = records.get(i).getQu();
            QueryWrapper<District> qqqqw = new QueryWrapper<>();
            qqqqw.eq("code",qu);
            District one2 = districtService.getOne(qqqqw);
            records.get(i).setQu(one2.getName());
        }
        DataVo<Jiezhongdian> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(districtPage.getRecords());
        return dataVo;
    }

    @PassToken
    @ApiOperation( value="获取所有的接种点信息")
    @GetMapping("/findAll")
    public Result findAll(){
        return Result.ok(iJiezhongdianService.findAll());
    }

    @PassToken
    @ApiOperation(value = "获取接种点下的所有的医护人员")
    @GetMapping("/findJiezhongdianWorker/{jiezhongdianId}")
    public Result findJiezhongdianWorker(@PathVariable Long jiezhongdianId){
        QueryWrapper<JiezhongdianWorker> qw=new QueryWrapper<>();
        qw.eq("jiezhongdian_id",jiezhongdianId);
        return Result.ok(iJiezhongdianWorkerService.list(qw));
    }

    @ApiOperation( value="获取某接种点信息的详情")
    @GetMapping("/get/{id}")
    @PassToken
    public Result get(@PathVariable Long id){
        Jiezhongdian jzd = iJiezhongdianService.getById(id);
        System.out.println(jzd);
        return Result.ok(jzd);
    }






    /**
     * 添加接种点方法
     * @param name 接种点名称
     * @param sheng 省
     * @param shi 市
     * @return 执行结果
     */
    //调用adminService
    @ApiOperation(value = "添加接种点")
    @PostMapping("/save")
    @CrossOrigin
    public Result<Jiezhongdian> sava(String name, String sheng, String shi,
                                           String qu, String address){
        Jiezhongdian jiezhongdian = new Jiezhongdian();


        String shengCode=null;
        String shiCode=null;
        String quCode=null;
        List<District> sheng1 = districtService.findSheng();
        for (int i=0;i<sheng1.size();i++){
            if (sheng.equals(sheng1.get(i).getName())&&!StringUtils.isEmpty(sheng)){
                shengCode= sheng1.get(i).getCode();
                jiezhongdian.setSheng(shengCode);
            }
        }
        List<District> shi1 = districtService.findShi(shengCode);
        for (int i=0;i<shi1.size();i++){
            if (shi.equals(shi1.get(i).getName())&&!StringUtils.isEmpty(shi)){
                shiCode= shi1.get(i).getCode();
                jiezhongdian.setShi(shiCode);
            }
        }
        List<District> qu1 = districtService.findQu(shiCode);
        for (int i=0;i<qu1.size();i++){
            if (qu.equals(qu1.get(i).getName())&&!StringUtils.isEmpty(qu)){
                quCode= qu1.get(i).getCode();
                jiezhongdian.setQu(quCode);
            }
        }
          jiezhongdian.setName(name);

        jiezhongdian.setAddress(address);

        //调用service
        try {
            boolean save = iJiezhongdianService.save(jiezhongdian);
            return Result.ok("success");
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

    /**
     * 更新接种点信息方法
     * 注意点：
     * 1.账号唯一
     * 2.密码长度2-12
     *
     * @param
     * @return 执行结果
     */
    @ApiOperation(value = "更新接种点信息")
    @PostMapping("/update")
    @CrossOrigin
    public Result<Jiezhongdian> update(Jiezhongdian jiezhongdian){


        String sheng = jiezhongdian.getSheng();
        String shi = jiezhongdian.getShi();
        String qu = jiezhongdian.getQu();

        String shengCode=null;
        String shiCode=null;
        String quCode=null;

        List<District> sheng1 = districtService.findSheng();
        for (int i=0;i<sheng1.size();i++){
            if (sheng.equals(sheng1.get(i).getName())&&!StringUtils.isEmpty(sheng)){
                shengCode= sheng1.get(i).getCode();
                jiezhongdian.setSheng(shengCode);
            }
        }
        List<District> shi1 = districtService.findShi(shengCode);
        for (int i=0;i<shi1.size();i++){
            if (shi.equals(shi1.get(i).getName())&&!StringUtils.isEmpty(shi)){
                shiCode= shi1.get(i).getCode();
                jiezhongdian.setShi(shiCode);
            }
        }
        List<District> qu1 = districtService.findQu(shiCode);
        for (int i=0;i<qu1.size();i++){
            if (qu.equals(qu1.get(i).getName())&&!StringUtils.isEmpty(qu)){
                quCode= qu1.get(i).getCode();
                jiezhongdian.setQu(quCode);
            }
        }

        //调用service
        try {
            boolean save = iJiezhongdianService.updateById(jiezhongdian);
            return Result.ok("success");
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除接种点
     * @param id 接种点
     * @return 执行结果
     */
    @ApiOperation(value = "删除接种点")
    @GetMapping("/delate")
    @CrossOrigin
    public Result delate(String id){
        //调用service
        try {
            int i = Integer.parseInt(id);
            boolean b = iJiezhongdianService.removeById(i);

            System.out.println(b);
            if (b){
                return Result.ok("success");
            }else {
                return Result.noAuth("no");
            }

        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }





//    @ApiOperation("分页获取接种点的信息")
//    @CrossOrigin
//    @GetMapping("/pageQuery")
//    public DataVo<Jiezhongdian> pageQuery(Integer page, Integer limit){
//        if(page==null)page=1;
//        if(limit==null)limit=10;
//        Page<Jiezhongdian> districtPage =new Page<>();
//        districtPage.setSize(limit);
//        districtPage.setCurrent(page);
//        QueryWrapper<Jiezhongdian> qw =new QueryWrapper<>();
//
//        districtPage = iJiezhongdianService.page(districtPage,qw);
//        DataVo<Jiezhongdian> dataVo =new DataVo<>();
//        dataVo.setMsg("成功获取数据");
//        dataVo.setCode(0);
//        dataVo.setCount((int) districtPage.getTotal());
//        dataVo.setData(districtPage.getRecords());
//        return dataVo;
//    }





}

