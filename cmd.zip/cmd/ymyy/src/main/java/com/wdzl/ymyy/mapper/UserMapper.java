package com.wdzl.ymyy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wdzl.ymyy.entity.User;

public interface UserMapper extends BaseMapper<User> {

}
