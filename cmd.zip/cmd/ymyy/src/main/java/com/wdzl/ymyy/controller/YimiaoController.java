package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.DataVo;
import com.wdzl.ymyy.entity.Qiandao;
import com.wdzl.ymyy.entity.Yimiao;
import com.wdzl.ymyy.service.IYimiaoService;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "疫苗相关数据接口")
@CrossOrigin
@RestController
@RequestMapping("/yimiao")
public class YimiaoController {

    @Autowired
    private IYimiaoService iYimiaoService;

    @GetMapping("/findAll")
    public Result findAll(){
        return Result.ok(iYimiaoService.list());
    }

    @ApiOperation("分页获取疫苗记录的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<Yimiao> pageQuery(String yimiaoZhonglei,Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<Yimiao> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<Yimiao> qw =new QueryWrapper<>();
        if(StringUtils.isNotEmpty(yimiaoZhonglei)){
            qw.like("yimiao_zhonglei",yimiaoZhonglei);
        }
//        qw.orderByAsc("code");// 按照编码的升序显示；
        districtPage = iYimiaoService.page(districtPage,qw);
        DataVo<Yimiao> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(districtPage.getRecords());
        return dataVo;
    }

    @ApiOperation("新增疫苗信息")
    @PostMapping("/save")
    public Result save(Yimiao yimiao){
        try{
            iYimiaoService.save(yimiao);
            return Result.ok("新增成功");
        }catch (Exception e){
            e.printStackTrace();
            return Result.error("新增失败："+e.getMessage());
        }
    }
    @ApiOperation("修改疫苗信息")
    @PostMapping("/update")
    public Result update(Yimiao yimiao){
        try{
            iYimiaoService.updateById(yimiao);
            return Result.ok("修改成功");
        }catch (Exception e){
            e.printStackTrace();
            return Result.error("修改失败："+e.getMessage());
        }
    }

    @ApiOperation("删除疫苗信息")
    @GetMapping("/del/{id}")
    public Result del(@PathVariable Long id){
        try{
            System.out.println(id);
            System.out.println(iYimiaoService.removeById(id));
            return Result.ok("删除成功");
        }catch (Exception e){
            e.printStackTrace();
            return Result.error("删除失败："+e.getMessage());
        }
    }
}

