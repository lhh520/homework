package com.wdzl.ymyy.service;

import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface IJiezhongdianWorkerService extends IService<JiezhongdianWorker> {

    /**
     * 根据用户名获取接种者工作者
     * @param username
     * @return
     */
    public JiezhongdianWorker findByUsername(String username);
}
