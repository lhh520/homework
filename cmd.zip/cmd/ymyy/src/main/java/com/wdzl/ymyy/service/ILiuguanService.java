package com.wdzl.ymyy.service;

import com.wdzl.ymyy.entity.Liuguan;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface ILiuguanService extends IService<Liuguan> {

    void liuguan(Liuguan liuguan);
}
