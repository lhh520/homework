package com.wdzl.ymyy.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@RestController
@RequestMapping("/yimiao-lishi")
public class YimiaoLishiController {

}

