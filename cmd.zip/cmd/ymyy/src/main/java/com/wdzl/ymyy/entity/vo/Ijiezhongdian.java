package com.wdzl.ymyy.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;

public class Ijiezhongdian {
    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "接种点名称")
    private String name;

    @ApiModelProperty(value = "省")
    private String sheng;

    @ApiModelProperty(value = "市")
    private String shi;

    @ApiModelProperty(value = "县")
    private String qu;

    @ApiModelProperty(value = "地址")
    private String address;
}
