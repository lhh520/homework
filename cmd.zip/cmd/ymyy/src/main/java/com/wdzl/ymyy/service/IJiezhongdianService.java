package com.wdzl.ymyy.service;

import com.wdzl.ymyy.entity.Jiezhongdian;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 接种点信息 服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface IJiezhongdianService extends IService<Jiezhongdian> {

    List<Map<String,Object>> findAll();
}
