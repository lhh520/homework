package com.wdzl.ymyy.utils;

import lombok.Data;

import java.io.Serializable;

@Data
public class Result<T>  implements Serializable {

    private int code=200;
    /**
     * 成功标志
     */
    private boolean success = true;

    private String message="操作成功";
    private T data;

    public static Result ok(String message){
        Result result =new Result();
        result.setMessage(message);
        return result;
    }

    public static Result ok(Object objs){
        Result result =new Result();
        result.setData(objs);
        return result;
    }

    public static Result error(int code){
        Result result =new Result();
        result.setSuccess(false);
        result.setMessage("操作失败");
        result.setCode(code);
        return result;
    }

    public static Result error(String message){
        Result result =new Result();
        result.setMessage(message);
        result.setSuccess(false);
        result.setCode(500);
        return result;
    }

    /**
     * 认证失败
     * @param message
     * @return
     */
    public static Result noAuth(String message){
        Result result =new Result();
        result.setMessage(message);
        result.setSuccess(false);
        result.setCode(510);
        return result;
    }



}
