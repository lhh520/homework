package com.wdzl.ymyy.service.impl;

import com.wdzl.ymyy.entity.YimiaoLishi;
import com.wdzl.ymyy.mapper.YimiaoLishiMapper;
import com.wdzl.ymyy.service.IYimiaoLishiService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class YimiaoLishiServiceImpl extends ServiceImpl<YimiaoLishiMapper, YimiaoLishi> implements IYimiaoLishiService {

}
