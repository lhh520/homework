package com.wdzl.ymyy.entity;

import lombok.Data;

@Data
public class EChars {
    private Integer yuyue;
    private Integer yujian;
    private Integer jiezhong;

}
