package com.wdzl.ymyy.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class User implements Serializable {

    private  Long id;

    private String username;
    @TableField(value = "real_name")
    private String realName;
    private String card;// 身份证号
    private String area;// 所属行政区划
    private String address;// 地址
    private String phone;// 联系电话

    private String password;
}
