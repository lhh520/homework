package com.wdzl.ymyy.service.impl;

import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.entity.Liuguan;
import com.wdzl.ymyy.entity.Yuyue;
import com.wdzl.ymyy.mapper.JiezhongdianWorkerMapper;
import com.wdzl.ymyy.mapper.LiuguanMapper;
import com.wdzl.ymyy.mapper.YuyueMapper;
import com.wdzl.ymyy.service.ILiuguanService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class LiuguanServiceImpl extends ServiceImpl<LiuguanMapper, Liuguan> implements ILiuguanService {
    @Autowired
    private YuyueMapper yuyueMapper;
    @Autowired
    private JiezhongdianWorkerMapper jiezhongdianWorkerMapper;

    @Override
    public void liuguan(Liuguan liuguan){
        JiezhongdianWorker worker = jiezhongdianWorkerMapper.selectById(liuguan.getCreator());
        liuguan.setJiezhongdianId(worker.getJiezhongdianId());
        Yuyue yuyue = yuyueMapper.selectById(liuguan.getYuyueId());
        if(yuyue.getJiezhongdianId().longValue() != worker.getJiezhongdianId().longValue()){
            throw  new RuntimeException("预约地点与接种地点不一致");
        }
        liuguan.setJiezhongren(yuyue.getUserId());

        save(liuguan);
        // 更新预约记录的状态
//        Long yyId = liuguan.getYuyueId();
//        Yuyue yuyue = yuyueMapper.selectById(yyId);
        yuyue.setStatus(1);
        yuyueMapper.updateById(yuyue);
    }
}
