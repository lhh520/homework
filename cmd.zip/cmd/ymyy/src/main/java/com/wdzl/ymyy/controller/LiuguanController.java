package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.entity.vo.LiuguanVo;
import com.wdzl.ymyy.service.*;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 留观记录
 * <p>
 *  前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "留观记录相关数据接口")
@CrossOrigin
@RestController
@RequestMapping("/liuguan")
public class LiuguanController {

    @Autowired
    private ILiuguanService iLiuguanService;

    @Autowired
    private IJiezhongService iJiezhongService;

    @Resource
    private UserService userService;

    @Resource
    private IJiezhongdianWorkerService jiezhongdianWorkerService;

    @Resource
    private IJiezhongdianService jiezhongdianService;

    @ApiOperation("分页获取留观记录的信息")
    @CrossOrigin
    @GetMapping("/pageQuery")
    public DataVo<LiuguanVo> pageQuery(String username,Integer page, Integer limit){
        if(page==null)page=1;
        if(limit==null)limit=10;
        Page<Liuguan> districtPage =new Page<>();
        districtPage.setSize(limit);
        districtPage.setCurrent(page);
        QueryWrapper<Liuguan> qw =new QueryWrapper<>();

        QueryWrapper<User> qw1 = new QueryWrapper<>();
        if (!StringUtils.isEmpty(username)){
            qw1.like("real_name", username);
            List<User> list = userService.list(qw1);
            for (int i = 0; i < list.size(); i++) {
                qw.eq("jiezhongren", list.get(i).getId());
            }
        }
//        qw.orderByAsc("code");// 按照编码的升序显示；
        districtPage = iLiuguanService.page(districtPage,qw);

        List<Liuguan> records = districtPage.getRecords();


        System.out.println("***************************************");
        records.forEach(s-> System.out.println(s.toString()));
        System.out.println("***************************************");


        List<LiuguanVo> liuguanVos = new ArrayList<>();

        for (int i=0;i<records.size();i++){
            LiuguanVo liuguanVo = new LiuguanVo();
            //id
            liuguanVo.setId(records.get(i).getId());
            //接种人
            User byId = userService.getById(records.get(i).getJiezhongren());
            liuguanVo.setJiezhongren(byId.getRealName());
            //留观时长
            liuguanVo.setLiiuguanShichang(records.get(i).getLiiuguanShichang());
            //留观说明
            liuguanVo.setLiuguanShuoming(records.get(i).getLiuguanShuoming());
            //记录人
            JiezhongdianWorker byId1 = jiezhongdianWorkerService.getById(records.get(i).getCreator());
            liuguanVo.setCreator(byId1.getRealName());
            //接种时间
            liuguanVo.setCreateTime(records.get(i).getCreateTime());
            //接种点
            Jiezhongdian byId2 = jiezhongdianService.getById(records.get(i).getJiezhongdianId());
            liuguanVo.setJiezhongdianId(byId2.getName()+byId2.getAddress());
            //预约ID
            liuguanVo.setYuyueId(records.get(i).getYuyueId());
            liuguanVos.add(liuguanVo);

        }
        DataVo<LiuguanVo> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(liuguanVos);
        return dataVo;
    }

    //    @ApiOperation("分页获取留观记录的信息")
    //    @CrossOrigin
    //    @GetMapping("/pageQuery")
    //    public DataVo<Liuguan> pageQuery(Integer page, Integer limit){
    //        if(page==null)page=1;
    //        if(limit==null)limit=10;
    //        Page<Liuguan> districtPage =new Page<>();
    //        districtPage.setSize(limit);
    //        districtPage.setCurrent(page);
    //        QueryWrapper<Liuguan> qw =new QueryWrapper<>();
    ////        qw.orderByAsc("code");// 按照编码的升序显示；
    //        districtPage = iLiuguanService.page(districtPage,qw);
    //        DataVo<Liuguan> dataVo =new DataVo<>();
    //        dataVo.setMsg("成功获取数据");
    //        dataVo.setCode(0);
    //        dataVo.setCount((int) districtPage.getTotal());
    //        dataVo.setData(districtPage.getRecords());
    //        return dataVo;
    //    }

}

