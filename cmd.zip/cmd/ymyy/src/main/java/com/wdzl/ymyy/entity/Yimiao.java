package com.wdzl.ymyy.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Yimiao对象", description="")
public class Yimiao implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "疫苗种类")
    private String yimiaoZhonglei;

    @ApiModelProperty(value = "疫苗生产企业")
    private String yimiaoShengchanqiye;

    @ApiModelProperty(value = "需要注射的针剂数")
    private Integer zhenshu;//


}
