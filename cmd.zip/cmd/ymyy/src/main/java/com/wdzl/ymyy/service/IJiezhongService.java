package com.wdzl.ymyy.service;

import com.wdzl.ymyy.entity.Jiezhong;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface IJiezhongService extends IService<Jiezhong> {

    void jiezhong(Jiezhong qiandao);
}
