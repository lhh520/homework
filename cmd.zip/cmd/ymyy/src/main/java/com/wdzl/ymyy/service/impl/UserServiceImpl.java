package com.wdzl.ymyy.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wdzl.ymyy.entity.User;
import com.wdzl.ymyy.mapper.UserMapper;
import com.wdzl.ymyy.service.UserService;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import java.util.List;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public void register(User user) {
        if(StringUtils.isEmpty(user.getUsername()))
            user.setUsername(user.getPhone());
        // 验证账号是否存在
        QueryWrapper<User> qw =new QueryWrapper<>();
        qw.eq("username",user.getUsername());
        if(getBaseMapper().selectList(qw).size()>0){
            throw new RuntimeException("已经存在相同账号的用户");
        }
        save(user);
        //
    }

    @Override
    public User findByUserName(String username) {
        QueryWrapper<User> qw =new QueryWrapper<>();
         qw.eq("username",username);
        List<User> list =getBaseMapper().selectList(qw);
        if(list.size()==1){
            return list.get(0);
        }else if(list.size()>1){
            throw new RuntimeException("OK");
        }else {
            return null;
        }
    }
}
