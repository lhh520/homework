package com.wdzl.ymyy.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class Admin implements Serializable {
    private  Long id;

    private String username;
    @TableField(value = "real_name")
    private String realName;


    private String password;
}
