package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.annotation.PassToken;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.service.AddressService;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.exception.TokenUnavailable;
import com.wdzl.ymyy.service.IJiezhongService;
import com.wdzl.ymyy.service.IYuyueService;
import com.wdzl.ymyy.service.UserService;
import com.wdzl.ymyy.utils.JwtUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.util.StringUtils;

import javax.annotation.Resource;
@CrossOrigin
@Api(tags="接种者用户管理相关接口")
@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    @Autowired
    private IYuyueService iYuyueService;

    @Autowired
    private IJiezhongService iJiezhongService;
    @Autowired
    private AddressService addressService;

    // 接种人员注册
    @CrossOrigin
    @PostMapping("/register")
    @ApiOperation("用户注册")
    public Result register(@RequestBody User user){
        try{
            if(StringUtils.isEmpty(user.getUsername()))
                user.setUsername(user.getPhone());// 手机号码作为登录账号
            userService.register(user);
            return Result.ok("注册成功");
        }catch (Exception e){
            return Result.error("注册失败");
        }
    }

    /**
     * 预约
     * @param yuyue
     * @param token
     * @return
     */
    @ApiOperation("预约登记")
    @CrossOrigin
    @PostMapping("/yuyue")
    public Result yuyue(@RequestBody Yuyue yuyue, @RequestHeader("x-token") String token){

        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            yuyue.setUserId(Integer.parseInt(userId));// 设置预约人
//            yuyue.setYuyueriqi(LocalDate.now());
            yuyue.setStatus(0);// 0表示未完成；1表示已完成；
            System.out.println(yuyue.toString());
            Address address=addressService.getById(yuyue.getJiezhongdianId());
            address.setNum(address.getNum()+1);
            addressService.updateById(address);
            iYuyueService.yuyueaddress(address,userId);
            return Result.ok("添加历史成功");
        }catch (TokenUnavailable e){
            Result result = Result.error("验证失败:"+e.getMessage());
            result.setCode(501);
            return result;
        }catch (Exception e){
            return Result.error("OK："+e.getMessage());
        }
    }

    /**
     * 预约
     * @param yuyue
     * @param token
     * @return
     */
    @ApiOperation("预约登记")
    @CrossOrigin
    @PostMapping("/getYuyue")
    public Result getYuyue(@RequestBody Yuyue yuyue, @RequestHeader("x-token") String token){

        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            yuyue.setUserId(Integer.parseInt(userId));// 设置预约人
            yuyue.setStatus(1);// 0表示未完成；1表示已完成；
            System.out.println(yuyue.toString());
            Address address=addressService.getById(yuyue.getJiezhongdianId());
            address.setNum(address.getNum()+1);
            addressService.updateById(address);
            iYuyueService.yuyueaddress(address,userId);
            return Result.ok("添加历史成功");
        }catch (TokenUnavailable e){
            Result result = Result.error("验证失败:"+e.getMessage());
            result.setCode(501);
            return result;
        }catch (Exception e){
            return Result.error("发生错误："+e.getMessage());
        }
    }
    @PassToken
    @ApiOperation( value="获取所有的信息")
    @GetMapping("/findAll")
    public Result findAll(){
        return Result.ok(addressService.list());
    }
    @ApiOperation("完成预约信息")
    // 登记接种信息

    @PostMapping("/yuyue2")
    public Result yuyuechenggong(@RequestBody Yuyue qiandao, @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        System.out.println(token);
        try {
            System.out.println(token);
            System.out.println("----------");
            String userId = JwtUtils.getAudience(token);//工作人员签到
            System.out.println(userId);
            System.out.println("----------");
            iYuyueService.yuyuechenggong(qiandao,userId);
            return Result.ok("预约完成");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("OK：" + e.getMessage());
        }
    }




    @ApiOperation("获取接种人员预约记录")
    @CrossOrigin
    @GetMapping(value = "/findMyYuyues")
    public Result findMyYuyues( @RequestHeader("x-token") String token){
        try{
            String userId = JwtUtils.getAudience(token);
            QueryWrapper<Yuyue> qw =new QueryWrapper<>();
            qw.eq("user_id",Integer.parseInt(userId));
            qw.eq("status","0");
            qw.orderByDesc("yuyueriqi");
            return Result.ok(iYuyueService.list(qw));
        }catch (TokenUnavailable e){
            Result result = Result.error("验证失败:"+e.getMessage());
            result.setCode(501);
            return result;
        }catch (Exception e){
            return Result.error("OK:"+e.getMessage());
        }
    }

    @PassToken
    @ApiOperation( value="获取所有的接种点信息")
    @GetMapping("/getNum")
    public Result getNum(Address address, @RequestHeader("x-token") String token) throws TokenUnavailable {
        //return Result.ok(iJiezhongdianService.findAll());

            System.out.println(1);
            //String userId = JwtUtils.getAudience(token);
            int num=address.getId();
            Address address1=addressService.getById(num);
            return Result.ok(address1.getNum());


    }


    @ApiOperation("获取接种人员接种记录")
    @CrossOrigin
    @GetMapping(value = "/findMyJiezhong")
    public Result findMyJiezhong( @RequestHeader("x-token") String token){
        try{
            String userId = JwtUtils.getAudience(token);
            QueryWrapper<Jiezhong> qw =new QueryWrapper<>();
            qw.eq("jiezhongren",Integer.parseInt(userId));
            qw.orderByDesc("create_time");
            return Result.ok(iJiezhongService.list(qw));
        }catch (TokenUnavailable e){
            Result result = Result.error("验证失败:"+e.getMessage());
            result.setCode(501);
            return result;
        }catch (Exception e){
            return Result.error("发生错误:"+e.getMessage());
        }
    }
    /**
     *分页查询
     * @param page 当前页码
     * @param limit 最大记录数
     * @return 分页结果
     */
    @ApiOperation(value = "分页获取所有用户")

    @PostMapping("/list")
    @CrossOrigin
    public DataVo list(@RequestParam(defaultValue = "1") Integer page,
                       @RequestParam(defaultValue = "5") Integer limit){


        Page<User> p1 = new Page<>();
        p1.setCurrent(page);//当前页
        p1.setSize((long)limit);//每页最多条数
        Page<User> page1 = userService.page(p1);
        page1.getRecords().forEach(s-> System.out.println(s.toString()));
        DataVo dataVo=new DataVo();
        dataVo.setCode(0);
        dataVo.setMsg("成功");
        dataVo.setCount((int)page1.getTotal());
        dataVo.setData(page1.getRecords());

        // Result.ok(page1.getRecords()).setCode(0);
        return dataVo;
    }
    ///////////
    @ApiOperation(value = "添加用户")
    @PostMapping("/save")
    @CrossOrigin
    public String sava1(User user){
        //调用service
        try {
            boolean save = userService.save(user);
            return "ok";
        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }

    /**
     * 更新用户信息方法
     * 注意点：
     * 1.账号唯一
     * 2.密码长度2-12
     *
     * @param admin
     * @return 执行结果
     */
    @ApiOperation(value = "更新用户信息")
    @PostMapping("/update")
    @CrossOrigin
    public String update1(User admin){


        //调用service
        try {
            boolean save = userService.updateById(admin);
            return "ok";
        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }
    /**
     * 删除用户
     * @param id 用户id
     * @return 执行结果
     */
    @ApiOperation(value = "删除用户")
    @GetMapping("/delate")
    @CrossOrigin
    public String delate1(int id){
        //调用service
        try {
            boolean b = userService.removeById(id);
            System.out.println(b);
            if (b){
                return "ok";
            }else {
                return "no";
            }

        }catch (Exception e){
            return "错误："+e.getMessage();
        }
    }



//    // 登录（不验证）
//    @CrossOrigin(origins = "*")
//    @PassToken(required = false)
//    @RequestMapping(value = "/validate", method = RequestMethod.POST)
//    public Result validate(@RequestBody UserToken userToken) {
//        System.out.println(">>>" + userToken);
//        try {
//            // 获取 token 中的 user Name
//            String userType = JwtUtils.getClaimByName(userToken.getToken(),"userType").asString();
//            if(!"jiezhongzhe".equals(userType)){
//                throw new RuntimeException("用户的身份不符");
//            }
//            String userId = JwtUtils.getAudience(userToken.getToken());
//            System.out.println(">>>" + userId);
//            JwtUtils.verifyToken(userToken.getToken(), userId);
//            return Result.ok("验证成功");
//        } catch (Exception e) {
//            Result result = Result.error("验证失败");
//            result.setCode(510);
//            return result;
//        }
//
//    }








}
