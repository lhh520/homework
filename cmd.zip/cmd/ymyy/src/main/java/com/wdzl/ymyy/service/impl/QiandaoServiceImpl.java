package com.wdzl.ymyy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.entity.Qiandao;
import com.wdzl.ymyy.entity.Yuyue;
import com.wdzl.ymyy.mapper.JiezhongdianWorkerMapper;
import com.wdzl.ymyy.mapper.QiandaoMapper;
import com.wdzl.ymyy.mapper.YuyueMapper;
import com.wdzl.ymyy.service.IQiandaoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class QiandaoServiceImpl extends ServiceImpl<QiandaoMapper, Qiandao> implements IQiandaoService {

    @Resource
    private JiezhongdianWorkerMapper jiezhongdianWorkerMapper;
    @Resource
    private YuyueMapper yuyueMapper;

    public void qiandao(Qiandao obj){
        //        1.若预约有效
//        2.判断预约点和签到点是否一致；
//        3.判断当前系统日期和预约日期是否一致；
//        4.不能重复签到（同一预约码，同一天不能签到两次）
        Yuyue yuyue = yuyueMapper.selectById(obj.getYuyueId());
        /////
        obj.setYuyueId(yuyue.getId());
        /////
        obj.setQiandaoren(yuyue.getUserId());
        LocalDate yyrq = yuyue.getYuyueriqi();
        LocalDate localDate = LocalDate.now();
        int value = localDate.compareTo(yyrq);
        if(value>0){
            throw new RuntimeException("预约已过期");
        }
        if(value <0){
            throw new RuntimeException("预约日期还未到");
        }
        // 获取工作人的所在的地点
        JiezhongdianWorker worker = jiezhongdianWorkerMapper.selectById(obj.getCreator());
        if(worker.getJiezhongdianId().intValue()!=yuyue.getJiezhongdianId().intValue()){
            throw new RuntimeException("预约地点与接种点不符");
        }
        //是否已经存在签到记录
        QueryWrapper<Qiandao> qw=new QueryWrapper<>();
        qw.eq("yuyue_id",obj.getYuyueId());
        int count =baseMapper.selectCount(qw);
        if(count>0){
            throw new RuntimeException("已经存在签到记录");
        }
        obj.setQiandao(LocalDateTime.now());//系统当前时间
        //obj.setQiandaoren(worker.getId());
        /////
        obj.setDiezhongdianId(worker.getJiezhongdianId());
        System.out.println(obj.toString());
        baseMapper.insert(obj);
    }
}
