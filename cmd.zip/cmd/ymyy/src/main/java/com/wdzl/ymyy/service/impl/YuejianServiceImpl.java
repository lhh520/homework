package com.wdzl.ymyy.service.impl;

import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.entity.Yuejian;
import com.wdzl.ymyy.entity.Yuyue;
import com.wdzl.ymyy.mapper.JiezhongdianWorkerMapper;
import com.wdzl.ymyy.mapper.YuejianMapper;
import com.wdzl.ymyy.mapper.YuyueMapper;
import com.wdzl.ymyy.service.IYuejianService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class YuejianServiceImpl extends ServiceImpl<YuejianMapper, Yuejian> implements IYuejianService {

    @Autowired
    private JiezhongdianWorkerMapper jiezhongdianWorkerMapper;
    @Autowired
    private YuyueMapper yuyueMapper;

    public void yujian(Yuejian yuejian){
        JiezhongdianWorker worker = jiezhongdianWorkerMapper.selectById(yuejian.getCreator());
        yuejian.setJiezhongdianId(worker.getJiezhongdianId());
        Yuyue yuyue = yuyueMapper.selectById(yuejian.getYuyueId());
        if(yuyue.getJiezhongdianId().longValue() != worker.getJiezhongdianId().longValue()){
            throw  new RuntimeException("预约地点与接种地点不一致");
        }
        yuejian.setJiezhongren(yuyue.getUserId());
        save(yuejian);

    }
}
