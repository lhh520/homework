package com.wdzl.ymyy.mapper;

import com.wdzl.ymyy.entity.YimiaoLishi;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface YimiaoLishiMapper extends BaseMapper<YimiaoLishi> {

}
