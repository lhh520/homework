package com.wdzl.ymyy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.entity.JiezhongdianWorker;
import com.wdzl.ymyy.mapper.JiezhongdianWorkerMapper;
import com.wdzl.ymyy.service.IJiezhongdianWorkerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Service
public class JiezhongdianWorkerServiceImpl extends ServiceImpl<JiezhongdianWorkerMapper, JiezhongdianWorker> implements IJiezhongdianWorkerService {

    public JiezhongdianWorker findByUsername(String username){
        QueryWrapper<JiezhongdianWorker> qw =new QueryWrapper<>();
        qw.eq("username",username);
        List<JiezhongdianWorker> list = list(qw);
        if (list.size() > 1) {
            throw new RuntimeException("存在多个用户");
        }else if(list.size()==1){
            return list.get(0);
        }else{
            return null;
        }
    }
}
