package com.wdzl.ymyy.service;

import com.wdzl.ymyy.entity.Address;
import com.wdzl.ymyy.entity.Yuyue;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 预约记录 服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface IYuyueService extends IService<Yuyue> {

    public void yuyue(Yuyue yuyue) ;
    public void yuyueaddress(Address address,String userId) ;
    public void yuyuechenggong(Yuyue yuyue,String workerId) ;
}
