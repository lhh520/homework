package com.wdzl.ymyy.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.annotation.PassToken;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.exception.TokenUnavailable;
import com.wdzl.ymyy.service.*;
import com.wdzl.ymyy.utils.JwtUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "医护工作人员相关接口")
@CrossOrigin
@RestController
@RequestMapping("/worker")
public class WorkerController {

    @Autowired
    private IJiezhongdianWorkerService iJiezhongdianWorkerService;

    @Autowired
    private IQiandaoService iQiandaoService;
    @Autowired
    private IYuyueService iYuyueService;

    @Autowired
    private IYuejianService iYuejianService;
    @Autowired
    private IJiezhongService iJiezhongService;
    @Autowired
    private ILiuguanService iLiuguanService;
    @Autowired
    private IYimiaoService iYimiaoService;
    @Autowired
    private IYimiaoLishiService iYimiaoLishiService;

    // 登记留观信息
    @ApiOperation("登记留观信息,同时更改预约的状态")
    @PostMapping("/liuguan")
    public Result liuguan(@RequestBody Liuguan liuguan, @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            liuguan.setCreateTime(LocalDateTime.now());
            liuguan.setCreator(Integer.parseInt(userId));


            iLiuguanService.liuguan(liuguan);
            return Result.ok("添加留观记录成功");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }

    @ApiOperation("登记接种信息")
    // 登记接种信息
    @PostMapping("/jiezhong")
    public Result jiezhong(@RequestBody Jiezhong qiandao, @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            qiandao.setCreateTime(LocalDateTime.now());
            qiandao.setCreator(Integer.parseInt(userId));

            iJiezhongService.jiezhong(qiandao);
            return Result.ok("添加接种记录成功");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }
    //处理预约


    @ApiOperation("登记预检信息")
    // 登记预检信息
    @PostMapping("/yujian")
    public Result yujian(@RequestBody Yuejian yuejian, @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            yuejian.setCreateTime(LocalDateTime.now());
            yuejian.setCreator(Integer.parseInt(userId));

            iYuejianService.yujian(yuejian);
            return Result.ok("预检成功");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }

    @ApiOperation("登记签到信息")
    //  签到确认
    @PostMapping("/qiandao")
    public Result qiandao(@RequestBody Qiandao qiandao, @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            qiandao.setQiandao(LocalDateTime.now());
            qiandao.setCreator(Integer.parseInt(userId));


            iQiandaoService.qiandao(qiandao);
            return Result.ok("签到成功");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(510);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }
    @PostMapping("/yuyue2")
    public Result yuyuechenggong(@RequestBody Yuyue qiandao, @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        System.out.println(token);
        try {
            System.out.println(token);
            System.out.println("----------");
            String userId = JwtUtils.getAudience(token);//工作人员签到
            System.out.println(userId);
            System.out.println("----------");
            iYuyueService.yuyuechenggong(qiandao,userId);
            return Result.ok("预约完成");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }
    @PostMapping("/yuyue3")
    public Result yuyue3(@RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name

        try {
            System.out.println(token);
            System.out.println("----------");
            String userId = JwtUtils.getAudience(token);//工作人员签到
            System.out.println(userId);
            System.out.println("----------");

            return Result.ok("预约完成");
        } catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }
//    @ApiOperation("工作人员登录")
//    @PostMapping("/login")
//    public Result login(@RequestBody UsernameAndPw up) {
//        try {
//            if (StringUtils.isEmpty(up.getUsername())) {
//                throw new RuntimeException("用户名不能为空");
//            }
//            if (StringUtils.isEmpty(up.getPassword())) {
//                throw new RuntimeException("密码不能为空");
//            }
//            QueryWrapper<JiezhongdianWorker> qw = new QueryWrapper<>();
//            qw.eq("username", up.getUsername());
//            List<JiezhongdianWorker> list = iJiezhongdianWorkerService.list(qw);
//            if (list.size() > 1) {
//                return Result.error("存在多个用户");
//            } else if (list.size() == 0) {
//                return Result.error("查无此用户");
//            } else {
//                // 查到用户
//                JiezhongdianWorker loginUser = list.get(0);
//                if (!up.getPassword().equals(loginUser.getPassword())) {
//                    return Result.error("密码错误");
//                } else {
//                    loginUser.setPassword(null);
//                    JSONObject obj = new JSONObject();
//                    obj.put("loginUser", loginUser);
//                    obj.put("token", JwtUtils.createToken(loginUser.getId() + "", loginUser.getUsername(), loginUser.getRealName(), "worker"));
//                    return Result.ok(obj);
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return Result.error("登录失败");
//        }
//    }

    @ApiOperation("获取我记录的签到记录")
    @GetMapping("/findMyQiandao")
    public Result findMyQiandao( @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            QueryWrapper<Qiandao> qw = new QueryWrapper<>();
            qw.eq("creator",Integer.parseInt(userId));
            qw.orderByDesc("qiandao");
            return Result.ok(iQiandaoService.list(qw));

        }catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }

    }

    @ApiOperation("获取我记录的预检记录")
    @GetMapping("/findMyYujian")
    public Result findMyYujian( @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            QueryWrapper<Yuejian> qw = new QueryWrapper<>();
            qw.eq("creator",Integer.parseInt(userId));
            qw.orderByDesc("create_time");
            return Result.ok(iYuejianService.list(qw));
        }catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }

    @ApiOperation("获取我记录的接种记录")
    @GetMapping("/findMyJiezhong")
    public Result findMyJiezhong( @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            QueryWrapper<Jiezhong> qw = new QueryWrapper<>();
            qw.eq("creator",Integer.parseInt(userId));
            qw.orderByDesc("create_time");
            return Result.ok(iJiezhongService.list(qw));

        }catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }


    @ApiOperation("获取我记录的留观记录")
    @GetMapping("/findMyLiuguan")
    public Result findMyLiuguan( @RequestHeader("x-token") String token) {
        // 获取 token 中的 user Name
        try {
            String userId = JwtUtils.getAudience(token);
            QueryWrapper<Liuguan> qw = new QueryWrapper<>();
            qw.eq("creator",Integer.parseInt(userId));
            qw.orderByDesc("create_time");
            return Result.ok(iLiuguanService.list(qw));


        }catch (TokenUnavailable e) {
            Result result = Result.error("验证失败:" + e.getMessage());
            result.setCode(501);
            return result;
        } catch (Exception e) {
            return Result.error("发生错误：" + e.getMessage());
        }
    }

//    // 登录（不验证）
//    @CrossOrigin(origins = "*")
//    @PassToken(required = false)
//    @RequestMapping(value = "/validate", method = RequestMethod.POST)
//    public Result validate(@RequestBody UserToken userToken) {
//        System.out.println(">>>" + userToken);
//        try {
//            // 获取 token 中的 user Name
//            String userType = JwtUtils.getClaimByName(userToken.getToken(),"userType").asString();
//            if(!"jiezhongzhe".equals(userType)){
//                throw new RuntimeException("用户的身份不符");
//            }
//            String userId = JwtUtils.getAudience(userToken.getToken());
//            System.out.println(">>>" + userId);
//            JwtUtils.verifyToken(userToken.getToken(), userId);
//            return Result.ok("验证成功");
//        } catch (Exception e) {
//            Result result = Result.error("验证失败");
//            result.setCode(510);
//            return result;
//        }
//
//    }


    @ApiOperation(value = "根据预约码获取预约人未完成的疫苗接种情况")
    @PassToken
    @GetMapping("/findWdwYimiao/{yuyueId}")
    public Result findWdwYimiao(@PathVariable Long yuyueId) {
        try{
            Yuyue yy = iYuyueService.getById(yuyueId);
            QueryWrapper<YimiaoLishi> qw = new QueryWrapper<>();
            qw.eq("jiezhongren_id", yy.getUserId());
            List<YimiaoLishi> list = iYimiaoLishiService.list(qw);
            List<YimiaoLishi>list2 =new ArrayList<>();
            for(YimiaoLishi ls :list){
                if(ls.getYidazhenshu().longValue()<ls.getZhenshu()){
                    list2.add(ls);
                }
            }
            return Result.ok(list2);
        }catch(Exception e){
            return Result.error("错误："+e.getMessage());
        }
    }

    @ApiOperation(value = "根据预约人Id获取其未完成的疫苗接种情况")
    @PassToken
    @GetMapping("/findWdwYimiaoByUserId/{userId}")
    public Result findWdwYimiaoByUserId(@PathVariable Long userId) {
        try{
            QueryWrapper<YimiaoLishi> qw = new QueryWrapper<>();
            qw.eq("jiezhongren_id", userId);
            List<YimiaoLishi> list = iYimiaoLishiService.list(qw);
            List<YimiaoLishi>list2 =new ArrayList<>();
            for(YimiaoLishi ls :list){
                if(ls.getYidazhenshu().longValue()<ls.getZhenshu()){
                    list2.add(ls);
                }
            }
            return Result.ok(list2);
        }catch(Exception e){
            return Result.error("错误："+e.getMessage());
        }
    }

    @PassToken
    @ApiOperation("获取某接种人某疫苗的当前针剂数")
    @GetMapping("/findCurrentZhenShu/{jiezhongzheId}/{yimiaoId}")
    public Result findCurrentZhenShu(@PathVariable Long jiezhongzheId,@PathVariable Long yimiaoId){
        QueryWrapper<YimiaoLishi> qw = new QueryWrapper<>();
        qw.eq("jiezhongren_id", jiezhongzheId);
        qw.eq("yimiao_id",yimiaoId);
        List<YimiaoLishi> list = iYimiaoLishiService.list(qw);
        JSONObject obj =new JSONObject();
        if(list.size()==0) {
            obj.put("currentZhenshu",1);
        }else if(list.size()==1){
            YimiaoLishi ls =list.get(0);
            if(ls.getYidazhenshu().longValue()<ls.getZhenshu()){
                obj.put("currentZhenshu",ls.getYidazhenshu().longValue()+1);

            }else{
                return Result.error("此用户当前疫苗接种针数已完成");
            }

        }else{
            return Result.error("用户疫苗接种数据出现问题");
        }

        return Result.ok(obj);


    }

    @ApiOperation("根据预约码获取其可以接种的疫苗及当前针次")
    @CrossOrigin
    @GetMapping("/findKjzYimiao/{yuyueId}")
    public Result findKzjYimao(@PathVariable Integer yuyueId){
        try {
            Yuyue yy = iYuyueService.getById(yuyueId);
            // 得到接种人id
            Integer userId = yy.getUserId();
            // 查询接种人所接种历史
            QueryWrapper<YimiaoLishi> qw = new QueryWrapper<>();
            qw.eq("jiezhongren_id", userId);
            List<YimiaoLishi> list = iYimiaoLishiService.list(qw);
            List<Map<String,Object>>re =new ArrayList<>();
            if(list.size()>0){
                for(YimiaoLishi ls :list) {
                    if (ls.getYidazhenshu().longValue() < ls.getZhenshu()) {
                        Map<String, Object> map = new HashMap<>();
                        map.put("yimiaoId", ls.getYimiaoId());
                        map.put("yimiaoZhonglei", ls.getYimiaoZhonglei());
                        map.put("yimiaoShenchanqiye", ls.getYimiaoShengchanqiye());
                        map.put("curZhenshu", ls.getYidazhenshu() + 1);
                        re.add(map);
                    }
                }
            }


            if(re.size()==0){
                iYimiaoService.list().forEach(s->{
                    Map<String,Object> map =new HashMap<>();
                    map.put("yimiaoId",s.getId());
                    map.put("yimiaoZhonglei",s.getYimiaoZhonglei());
                    map.put("yimiaoShenchanqiye",s.getYimiaoShengchanqiye());
                    map.put("curZhenshu",1);
                    re.add(map);
                });
            }

            return Result.ok(re);

        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

}

