package com.wdzl.ymyy.service;

import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.wdzl.ymyy.entity.Yimiao;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */

public interface IYimiaoService extends IService<Yimiao> {




}
