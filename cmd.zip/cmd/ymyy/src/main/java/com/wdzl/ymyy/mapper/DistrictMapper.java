package com.wdzl.ymyy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wdzl.ymyy.entity.District;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface DistrictMapper extends BaseMapper<District> {


}
