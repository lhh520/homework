package com.wdzl.ymyy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wdzl.ymyy.entity.Test;


public interface TestMapper extends BaseMapper<Test> {

}
