package com.wdzl.ymyy.entity.vo;

import lombok.Data;

import java.util.List;
@Data
public class EChartsVo {
    private List date;
    private List yuyue;

}
