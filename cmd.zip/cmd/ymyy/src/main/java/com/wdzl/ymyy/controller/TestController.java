package com.wdzl.ymyy.controller;

import com.wdzl.ymyy.utils.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/t001")
    public Result to(){
        int a=10/0;
        return Result.ok(">>>>>>>>>>>>>");
    }
}
