package com.wdzl.ymyy.mapper;

import com.wdzl.ymyy.entity.Yuyue;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 预约记录 Mapper 接口
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
public interface YuyueMapper extends BaseMapper<Yuyue> {

}
