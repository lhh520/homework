package com.wdzl.ymyy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wdzl.ymyy.entity.Admin;
import com.wdzl.ymyy.mapper.AdminMapper;
import com.wdzl.ymyy.service.AdminService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements AdminService {
    @Override
    public Admin findByUsername(String username) {
        QueryWrapper<Admin> qw = new QueryWrapper();
        qw.eq("username",username);
        List<Admin> list = getBaseMapper().selectList(qw);
        if(list.size()==1)return  list.get(0);
        else if(list.size()>1){
            throw new RuntimeException("该账号存在多个信息");
        }
        return null;
    }
}
