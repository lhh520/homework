package com.wdzl.ymyy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wdzl.ymyy.entity.*;
import com.wdzl.ymyy.entity.vo.Iyuyue;
import com.wdzl.ymyy.service.IJiezhongdianService;
import com.wdzl.ymyy.service.IYuyueService;
import com.wdzl.ymyy.service.UserService;
import com.wdzl.ymyy.utils.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 预约记录 前端控制器
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Api(tags = "预约记录相关数据接口")
@CrossOrigin
@RestController
@RequestMapping("/yuyue")
public class YuyueController {

    @Autowired
    private IYuyueService iYuyueService;

    @Autowired
    private UserService userService;

    @Autowired
    private IJiezhongdianService jiezhongdianService;

    @ApiOperation("分页获取疫苗记录的信息")
    @CrossOrigin
    @RequestMapping(value = "/pageQuery",method = {RequestMethod.POST,RequestMethod.GET})
    public DataVo<Iyuyue> pageQuery(String user, Integer page, Integer limit){
        //如果起始页为空则默认为第一页
        if(page==null)page=1;
        //如果每页数为空则默认为10条数据
        if(limit==null)limit=10;
        //分页插件
        Page<Yuyue> districtPage =new Page<>();
        //将每页数设置进去
        districtPage.setSize(limit);
        //将起始页设置进去
        districtPage.setCurrent(page);
        //针对预约表查询
        QueryWrapper<Yuyue> qw =new QueryWrapper<>();
        //从用户表查询出搜索栏中的用户集合
        QueryWrapper<User> qwUser = new QueryWrapper<>();
    if (!StringUtils.isEmpty(user)) {
            qwUser.like("real_name", user);
            List<User> list = userService.list(qwUser);
            //这里是将查询出来的接种者集合遍历出来id，再去预约表中查询userID，将userID作为条件在预约表中查询
            for (int i = 0; i < list.size(); i++) {
                Long id = list.get(i).getId();
                qw.eq("user_id", id);
            }
        }
//        qw.orderByAsc("code");// 按照编码的升序显示；
        districtPage = iYuyueService.page(districtPage,qw);
        //将查询出来的预约记录导入list中
        List<Yuyue> records = districtPage.getRecords();
        //将上面的记录进行封装，实体类为vo中的Iyuyue
        List<Iyuyue> iyuyues=new ArrayList<>();
        for (int i=0;i<records.size();i++){
            //创建一个Iyuyue对象，对数据进行封装
            Iyuyue iyuyue = new Iyuyue();
            iyuyue.setId(records.get(i).getId());
            //从用户表中查询用户，通过预约表中的用户ID
            User byId = userService.getById(records.get(i).getUserId());
            iyuyue.setUser(byId.getRealName());
            //从接种点表中查询出接种点信息,通过预约表中的接种点ID

            Jiezhongdian byId1 = jiezhongdianService.getById(records.get(i).getJiezhongdianId());
            iyuyue.setJiezhongdianName(byId1.getName());
            iyuyue.setJiezhongdianAddress(byId1.getAddress());

            iyuyue.setYuyueriqi(records.get(i).getYuyueriqi());
            iyuyue.setStatus(records.get(i).getStatus());
            iyuyue.setQrCodePath(records.get(i).getQrCodePath());
            iyuyues.add(iyuyue);

        }

        DataVo<Iyuyue> dataVo =new DataVo<>();
        dataVo.setMsg("成功获取数据");
        dataVo.setCode(0);
        dataVo.setCount((int) districtPage.getTotal());
        dataVo.setData(iyuyues);
        return dataVo;
    }

//    @ApiOperation("分页获取疫苗记录的信息")
//    @CrossOrigin
//    @RequestMapping(value = "/pageQuery",method = {RequestMethod.POST,RequestMethod.GET})
//    public DataVo<Yuyue> pageQuery(LocalDateTime yuyueriqi, Integer page, Integer limit){
//        if(page==null)page=1;
//        if(limit==null)limit=10;
//        Page<Yuyue> districtPage =new Page<>();
//        districtPage.setSize(limit);
//        districtPage.setCurrent(page);
//        QueryWrapper<Yuyue> qw =new QueryWrapper<>();
//        if(yuyueriqi != null){
//            qw.eq("yuyueriqi",yuyueriqi);
//        }
////        qw.orderByAsc("code");// 按照编码的升序显示；
//        districtPage = iYuyueService.page(districtPage,qw);
//        DataVo<Yuyue> dataVo =new DataVo<>();
//        dataVo.setMsg("成功获取数据");
//        dataVo.setCode(0);
//        dataVo.setCount((int) districtPage.getTotal());
//        dataVo.setData(districtPage.getRecords());
//        return dataVo;
//    }

}

