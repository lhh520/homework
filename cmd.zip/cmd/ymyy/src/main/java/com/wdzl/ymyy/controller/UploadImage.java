package com.wdzl.ymyy.controller;


import com.wdzl.ymyy.utils.Result;
import com.wdzl.ymyy.utils.FileUploadUtils;
import com.wdzl.ymyy.utils.Global;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;


/**
 *
 */
@CrossOrigin
@Controller
@Api( tags = "图片上传相关接口")
public class UploadImage {
    @ApiOperation(value = "图片上传接口")
    @PostMapping("/upload")
    @ResponseBody
    public Result updateAvatar(@RequestParam("imgFile") MultipartFile imgFile) throws IOException {
        /*判断图片不为空*/
        if (!imgFile.isEmpty()) {
            File fileDir = Global.getImgDirFile();  //返回生成的图片文件假根目录
            String avatar = FileUploadUtils.upload(fileDir, imgFile);
            return Result.ok(avatar);
        }
        return Result.error("上传失败！");
    }
}
