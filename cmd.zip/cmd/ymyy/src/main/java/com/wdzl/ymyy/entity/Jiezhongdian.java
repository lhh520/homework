package com.wdzl.ymyy.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 接种点信息
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Jiezhongdian对象", description="接种点信息")
public class Jiezhongdian implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "接种点名称")
    private String name;

    @ApiModelProperty(value = "省")
    private String sheng;

    @ApiModelProperty(value = "市")
    private String shi;

    @ApiModelProperty(value = "县")
    private String qu;

    @ApiModelProperty(value = "地址")
    private String address;


}
