package com.wdzl.ymyy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wdzl.ymyy.entity.User;

public interface UserService extends IService<User> {

    void register(User user);

    /**
     * 查询用户名所对应的用户信息
     * @param username
     * @return
     */
    User findByUserName(String username);
}
