package com.wdzl.ymyy.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author dwk
 * @since 2021-07-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Jiezhong对象", description="")
public class Jiezhong implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "接种人")
    private Integer jiezhongren;

    @ApiModelProperty(value = "接种部位")
    private String jiezhongbuwei;

//    @ApiModelProperty(value = "药物名称")
//    private String yaowumingcheng;

    @ApiModelProperty(value = "疫苗id")
    private Integer yimiaoId;

    @ApiModelProperty(value = "疫苗种类")
    private String yimiaoZhonglei;

    @ApiModelProperty(value = "疫苗生产企业")
    private String yimiaoShengchanqiye;

    @ApiModelProperty(value = "成剂数")
    private Integer chengjishu;

    @ApiModelProperty(value = "疫苗批号")
    private String yimiaoPihao;

    @ApiModelProperty(value = "记录人")
    private Integer creator;

    @ApiModelProperty(value = "记录时间")
    @JsonFormat(pattern = "yyyy-MM-dd YY:mm:ss", timezone="GMT+8")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "所属接种点")
    private Integer jiezhongdianId;

    @ApiModelProperty(value = "预约id")
    private Integer yuyueId;


}
