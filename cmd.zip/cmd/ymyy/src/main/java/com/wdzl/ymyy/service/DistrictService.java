package com.wdzl.ymyy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wdzl.ymyy.entity.District;

import java.util.List;

public interface DistrictService extends IService<District> {

    /**
     * 获取所有的省
     * @return
     */
    public List<District> findSheng();

    /**
     * 获取省下的市
     * @param code
     * @return
     */
    public List<District> findShi(String code);

    /**
     * 获取市下的区街办
     * @param code
     * @return
     */
    public List<District> findQu(String code);
}
