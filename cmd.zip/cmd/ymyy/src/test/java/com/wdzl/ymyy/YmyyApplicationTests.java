package com.wdzl.ymyy;
//
//import com.wdzl.ymyy.entity.User;
//import com.wdzl.ymyy.entity.Yuyue;
//import com.wdzl.ymyy.mapper.UserMapper;
//import com.wdzl.ymyy.service.DistrictService;
//import com.wdzl.ymyy.service.IYuyueService;
//import com.wdzl.ymyy.service.UserService;
//import org.junit.jupiter.api.Test;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wdzl.ymyy.entity.Qiandao;
import com.wdzl.ymyy.entity.Yimiao;
import com.wdzl.ymyy.entity.Yuyue;
import com.wdzl.ymyy.entity.vo.Iyuyue;
import com.wdzl.ymyy.mapper.TestMapper;
import com.wdzl.ymyy.mapper.YimiaoMapper;
import com.wdzl.ymyy.service.IQiandaoService;
import com.wdzl.ymyy.service.IYimiaoService;
import com.wdzl.ymyy.service.IYuejianService;
import com.wdzl.ymyy.service.IYuyueService;
import com.wdzl.ymyy.utils.utils.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

//
//import javax.annotation.Resource;
//import java.time.LocalDate;
//
@SpringBootTest
@MapperScan("com.wdzl.ymyy.mapper")
class YmyyApplicationTests {

    @Resource
    IYimiaoService iYimiaoService;

    @Resource
    TestMapper testMapper;

    @Autowired
    IYuyueService yuyueService;

    @Autowired
    IYuejianService yuejianService;


    @Autowired
    private IQiandaoService qiandaoService;


    @Test
    public void test01(){
        List<String> nDaysList = getNDaysList(null, DateUtils.dateStr(DateUtils.getNow(),"MM-dd"), 15);
        nDaysList.forEach(s -> System.out.println(s));
    }



    /**
     *  用户可以传入startTime或endTime任意一个或两个，也可以不传入
     *  当传入的时间间隔太长时，默认返回最近的nday
     *  plus: StringUtils为org.apache.commons.lang.StringUtils，读者也可以手动判断""和null
     */
    public static List<String> getNDaysList(String startTime, String endTime, int nday) {
        int ndaycurrent = nday - 1;
        // 返回的日期集合
        List<String> days = new ArrayList<String>();
        DateFormat dateFormat = new SimpleDateFormat("MM-dd");
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE,-ndaycurrent);
            Date start = calendar.getTime();
            Date end = new Date();
            if (StringUtils.isNotBlank(startTime) && StringUtils.isBlank(endTime)){
                //如果用户只选择了startTime,endTime为null,startTime + 10的日期
                start = dateFormat.parse(startTime);
                Calendar calendar1 = Calendar.getInstance();
                calendar1.setTime(start);
                calendar1.add(Calendar.DATE, ndaycurrent);
                end = calendar1.getTime();
            }else if(StringUtils.isBlank(startTime) && StringUtils.isNotBlank(endTime)){
                //如果用户只选择了endTime,startTime为null,endTime - 10的日期
                end = dateFormat.parse(endTime);
                Calendar calendar2 = Calendar.getInstance();
                calendar2.setTime(end);
                calendar2.add(Calendar.DATE, -ndaycurrent);
                start = calendar2.getTime();
            }else if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)){
                //如果用户选择了startTime和endTime，判断endTime - startTime两个日期是否超过了ndaycurrent，超过返回最近nday天记录
                Date start1 = dateFormat.parse(startTime);
                Date end1 = dateFormat.parse(endTime);
                int a = (int) ((end1.getTime() - start1.getTime()) / (1000*3600*24));
                if (a <= ndaycurrent) {
                    //如果小于等于n天
                    start = dateFormat.parse(startTime);
                    end = dateFormat.parse(endTime);
                }
            }
            //如果超过了ndaycurrent天,就是默认的start和end
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);

            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);// 日期加1(包含结束)

            while (tempStart.before(tempEnd)) {
                days.add(dateFormat.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return days;
    }

    @Test
    public void t04(){
        List dayListOfMonth = getDayListOfMonth();
       List<Integer> integers = new ArrayList<>();
        for(int i=0;i<dayListOfMonth.size();i++){
            String date = dayListOfMonth.get(i).toString();


            QueryWrapper<Qiandao> qwQiandao = new QueryWrapper<>();

            qwQiandao.between("qiandao",date+" 00:00:00",date+" 23.59.59");

            int count = qiandaoService.count(qwQiandao);
        integers.add(count);
        }

        for (int i=0;i<integers.size();i++){
            System.out.println((i+1)+"****"+integers.get(i));
        }
    }


    @Test
    public void t03(){
        List<List> allList = new ArrayList<>();
        List dayListOfMonth = getDayListOfMonth();
        List<Integer> yuyueList = new ArrayList<>();
        System.out.println(dayListOfMonth);
        for (int i=0;i<dayListOfMonth.size();i++){
            String date = dayListOfMonth.get(i).toString();
            QueryWrapper<Yuyue> qw = new QueryWrapper<>();
            qw.eq("yuyueriqi",date);
            int count = yuyueService.count(qw);
            yuyueList.add(count);

        }
        allList.add(dayListOfMonth);
        allList.add(yuyueList);


    }

    /**

     * 获取当月所有天

     * @return

     */

    public static List getDayListOfMonth() {
        List list = new ArrayList();

        Calendar aCalendar = Calendar.getInstance(Locale.CHINA);

        int year = aCalendar.get(Calendar.YEAR);//年份

        int month = aCalendar.get(Calendar.MONTH) + 1;//月份

        int day = aCalendar.getActualMaximum(Calendar.DATE);

        for (int i = 1; i <= day; i++) {
            String aDate = String.valueOf(year)+"-"+month+"-"+i;

            list.add(aDate);

        }

        return list;

    }


    @Test
    public void t02(){
        QueryWrapper<Yuyue> qw = new QueryWrapper<>();
        String s = DateUtils.dateStr2(DateUtils.getMonthStartTime());
        String s2="2021-7-20";
        String s1 = DateUtils.dateStr2(DateUtils.getMonthEndTime());
        System.out.println("************************************************");
        System.out.println(s+"SDSFASF"+s1);
        System.out.println("************************************************");
        qw.between("yuyueriqi",s2,s1);


//        System.out.println(date);
//        qw.eq("yuyueriqi ",date);
       List<Yuyue> list = yuyueService.list(qw);
        System.out.println(list);


    }

    @Test
    public void t01(){
        int count = yuejianService.count();
        System.out.println(count);

        int count1 = yuyueService.count();
        System.out.println(count1);

    }


    @Test
    public void tt(){
//        com.wdzl.ymyy.entity.Test t1 =new com.wdzl.ymyy.entity.Test();
//        t1.setName("1111");
//        testMapper.insert(t1);
    }
    @Test
    public void t1(){
//        Yimiao e =new Yimiao();
//        e.setZhenshu(1);
//        e.setYimiaoShengchanqiye(System.currentTimeMillis()+"");
//        e.setYimiaoZhonglei(""+System.currentTimeMillis());
//        iYimiaoService.save(e);
//        System.out.println(e.getId());
    }
//
//    @Autowired
//    private UserMapper userMapper;
//
//    @Resource
//    private UserService userService;
//
//    @Resource
//    private DistrictService districtService;
//
//    @Resource
//    private IYuyueService iYuyueService;
//
//    @Test
//    void c1(){
////        Yuyue yuyue =new Yuyue();
////        yuyue.setUserId(1L);
////        yuyue.setStatus(0);
////        yuyue.setYuyueriqi(LocalDate.now());
////        yuyue.setJiezhongdianId(1L);
////
////        iYuyueService.yuyue(yuyue);
//    }
//
//    @Test
//    void t1(){
//        districtService.findSheng().forEach(s->{
//            System.out.println(s.getCode()+" "+s.getName());
//            districtService.findShi(s.getCode()).forEach(x->{
//                System.out.println(">>"+x.getCode()+" "+x.getName());
//                districtService.findQu(x.getCode()).forEach(y->{
//                    System.out.println(">>>>"+y.getCode()+" "+y.getName());
//                });
//            });
//        });
//    }
//    @Test
//    void contextLoads() {
//        System.out.println(">>>>");
////        userMapper.selectByMap(null).forEach(s->{
////            System.out.println(s);
////        });
////        User user =new User();
////        user.setAddress("小寨西路111号");
////        user.setArea("陕西省西安市雁塔区");
////        user.setPhone("13710825068");
////        user.setCard("370481198109091212");
////        user.setName("gonggong");// 账号
////        user.setPassword("123321");
////        user.setRealName("共工");// 真实姓名
//////        user.setUserType(1);
////        userService.save(user);
//    }
//
}
