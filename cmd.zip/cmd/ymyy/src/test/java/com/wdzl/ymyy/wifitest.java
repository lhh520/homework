package com.wdzl.ymyy;

import com.alibaba.fastjson.JSONObject;
import com.wdzl.ymyy.utils.Global;
import com.wdzl.ymyy.utils.QRCodeUtil;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.UUID;

public class wifitest {
    @Test
    public void test() throws Exception {
        File file = new File (Global.getImgDirFile(), UUID.randomUUID().toString()+".png");
        String str="WIFI:T:WPA;S:60096009;P:60096009s;H:false;";
        String imgpath =  QRCodeUtil.generateQRCode(str, 400, 400, "png", file.getPath());
        System.out.println(imgpath);
    }
}
