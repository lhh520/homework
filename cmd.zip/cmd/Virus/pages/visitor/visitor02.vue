<template>
	
	<view class="page">
		
		<u-form :model="form" ref="uForm" label-width='150'>
				
				
				<u-swiper
				            :list="list1"
				            @change="change"
				            @click="click"
				></u-swiper>
				<u-notice-bar mode="horizontal" :list="list12"></u-notice-bar>
					<u-divider text="分割线"></u-divider>
				<view class="uni-padding-wrap uni-common-mt">
							<!-- <view class="text-box" scroll-y="true">
								<text>{{"香山公园（Fragrant Hills Park），位于北京市海淀区买卖街40号，北京市区西北郊，占地188公顷，是一座具有山林特色的皇家园林。景区内主峰香炉峰俗称鬼见愁，海拔575米。早在元、明、清时，皇家就在香山营建离宫别院，每逢夏秋时节皇帝都要到此狩猎纳凉。咸丰十年（1860年）和光绪二十六年（1900年）先后两次被英法联军、八国联军焚毁，1956年开辟为人民公园。香山公园有香山寺、洪光寺、双清别墅等著名旅游景点。"}}</text>
							</view> -->
							<u-read-more showHeight="200"> 
									<rich-text :nodes="content"></rich-text>
								</u-read-more>
							
								
				</view>
				
				<u-form-item label="已预约人数">
					<!-- <u-input disabled=true v-model="form.yuyuerenshu"/> -->
					<u-count-to :startVal="0" :endVal="yuyuepeople"></u-count-to>
				</u-form-item>
				<!-- <u-form-item label="预约日期">
					<u-input type='select' v-model="form.yuyueriqi" @click="show2=true"/>
					<u-calendar v-model="show2"  @change="setDate" :min-date="$u.timeFormat(new Date(),'yyyy-mm-dd')" :max-date="$u.timeFormat(new Date().setDate(new Date().getDate()+7),'yyyy-mm-dd')" ></u-calendar>
				</u-form-item> -->
				
				
				
				<u-collapse>
						<u-collapse-item :title="item.head" v-for="(item, index) in itemList" :key="index">
							{{item.body}}
						</u-collapse-item>
				</u-collapse>
				
				<u-button :loading="isLoading" @click="yuYue" type="success">Appointment</u-button>
		</u-form>
		<u-toast ref="uToast" />
				
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show3: false,
				selector: [1, 2, 3],
				itemList: [{
									head: "交通方式",
									body: "地铁：北京东路 ——> 北京东路——> 兰家庄——> 北京东路 ——> 龙蟠路——> 龙蟠路——> 玄武大道\n,火车：北京东路 ——> 北京东路——> 兰家庄——> 北京东路 ——> 龙蟠路——> 龙蟠路——> 玄武大道",
									open: true,
									disabled: true
								}],
				form:{
					yuyueriqi:'',
					yuyuerenshu:'50',
					jiezhongdianId:'2',
					jiezhongdianName:'香山',
					jiezhongdianAddress:'',
					
				},
				yuyuepeople:'',
				form1:{
					id:'2',
					addressname:'香山',
					num:'0'
				},
				list1: [
				                    'https://cdn.uviewui.com/uview/swiper/swiper1.png',
				                    'https://cdn.uviewui.com/uview/swiper/swiper2.png',
				                    'https://cdn.uviewui.com/uview/swiper/swiper3.png',
				                ],
				content: "Botanical Garden（Fragrant Hills Park），位于北京市海淀区买卖街40号，北京市区西北郊，占地188公顷，是一座具有山林特色的皇家园林。景区内主峰香炉峰俗称鬼见愁，海拔575米。早在元、明、清时，皇家就在香山营建离宫别院，每逢夏秋时节皇帝都要到此狩猎纳凉。咸丰十年（1860年）和光绪二十六年（1900年）先后两次被英法联军、八国联军焚毁，1956年开辟为人民公园。香山公园有香山寺、洪光寺、双清别墅等著名旅游景点。",
				text1: 'uView UI众多组件覆盖开发过程的各个需求，组件功能丰富，多端兼容。让您快速集成，开箱即用',
				show:false,
				show2:false,
				// list:['适合年龄段为60以下','比较刺激'],
				list12: [
									'适合年龄段为60以下',
									'比较刺激'
								],
				isLoading:false,
				src:'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fandroid-artworks.25pp.com%2Ffs01%2F2014%2F11%2F01%2F102_e52d0a2857f5dc15f14d4fdf970effe4.png&refer=http%3A%2F%2Fandroid-artworks.25pp.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1629466197&t=2f6a35af5b3b8f7e9998d323f4dbbf59'
			}
			
		},
		onLoad() {
			this.init();
		},
		methods: {
			init(){
				// this.$u.get('/jiezhongdian/findAll').then(res=>{
				// 	console.log(res)
				// 	if(res.success){
				// 		this.list=["南京","北京"]
				// 		this.list = res.data.map(function(item){
				// 			return {
				// 				label:item.name,
				// 				value:item.id,
							
				// 			}
				// 		})
				// 	}
				// })
				this.$u.get('/user/getNum',this.form1).then(res=>{
					console.log(res)
					if(res.success){
						console.log(res.data)
						this.yuyuepeople=res.data
					}
				})
				
				
				
			},
			setJieZhongDian(res){
				
				this.form.jiezhongdianId =2;
				this.form.jiezhongdianName =res[0].label;
			},
			setDate(res){
				this.form.yuyueriqi=res.result;
			},
			yuYue(){
				this.isLoading=true;
				this.$u.post("/user/yuyue",this.form).then(res=>{
					if(res.success){
						uni.showModal({
						    title: '预约成功',
						    content: '您已经预约成功！请您准时在预约的时间到达预约接种点完成预约',
							showCancel:false,
						    success(res) {
								if (res.confirm) {
									uni.navigateBack();
								}
							}
							})
					}else{
						this.$refs.uToast.show({
							title :res.message,
							type : 'error'
						})
					}
				}).finally(()=>{
					this.isLoading=false;
				})
			}
			
		}
	}
</script>

<style scoped>
.page{
		padding: 50rpx;
		
	}
.cover-image{
	display: block;
	margin: 0 auto;
}
</style>
