<template>
	<view class="page">
		
		<u-cell-group>
			<view>
				<u-toast ref="uToast" />
			<view class="map-container">
				<map style="width: 100%; height: 50vh;" :show-location='true' ref="map" id="map" :latitude="latitude"
					:longitude="longitude" :markers="marker" :scale="scale" @markertap="markertap" @callouttap='callouttap'>
					<cover-view class="cover-view" :style=''>
						<cover-view style="width: 10%; height: 5vh;" @click="refresh1">
							<cover-image class="cover-image" src="/static/logo.png"></cover-image>
							<cover-view>刷新</cover-view>
						</cover-view>
						<!-- <cover-view  style="width: 10%; height: 5vh;" @click="onControltap">
							<cover-image class="cover-image" src="/static/logo.png"></cover-image>
							<cover-view>定位</cover-view>
						</cover-view> -->
					 
					</cover-view>
				</map>
			</view>
			</view>
			<u-cell-item @click="goto('visitor01')" icon='pushpin' title="aquarium" label="There's a dolphin show"></u-cell-item>
			<u-cell-item @click="goto('visitor02')" icon='pushpin' title="Botanical Garden" label="There are various plants"></u-cell-item>
			<u-cell-item @click="goto('visitor03')" icon='pushpin' title="Zoo" label="There are many terrestrial creatures"></u-cell-item>
			<u-cell-item @click="goto('visitor04')" icon='pushpin' title="Marine Museum"label="There are many marine organisms"></u-cell-item>
			<!-- <u-cell-item @click="goto('jieZhongList')" icon='pushpin' title="铜锣鼓巷" label="铜锣鼓巷景点"></u-cell-item> -->
		</u-cell-group>
		<!-- <u-form :model="form" ref="uForm" label-width='150'>
				<u-form-item label="接种点">
					<u-input type='select' v-model="form.jiezhongdianName" @click="show=true"/>
					<u-select v-model='show' :list='list' @confirm='setJieZhongDian'></u-select>
				</u-form-item>
				<u-form-item label="预约日期">
					<u-input type='select' v-model="form.yuyueriqi" @click="show2=true"/>
					<u-calendar v-model="show2"  @change="setDate" :min-date="$u.timeFormat(new Date(),'yyyy-mm-dd')" :max-date="$u.timeFormat(new Date().setDate(new Date().getDate()+7),'yyyy-mm-dd')" ></u-calendar>
				</u-form-item>
				<u-button :loading="isLoading" @click="yuYue" type="success">疫苗预约</u-button>
		</u-form> -->
		<u-toast ref="uToast" />
				
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form:{
					yuyueriqi:'',
					jiezhongdianId:'',
					jiezhongdianName:'',
					jiezhongdianAddress:''
				},
				show:false,
				show2:false,
				list:[],
				isLoading:false,
				latitude: 34.82977, //纬度
				longitude: 113.66072, //经度
				scale: 12, //缩放级别
				
				marker: [{
						id: 0,
						latitude: 34.79977, //纬度
						longitude: 113.66072, //经度
						iconPath: '/static/logo.png', //显示的图标        
						rotate: 0, // 旋转度数
						width: 20, //宽
						height: 20, //高
						// title: '我在这里', //标注点名
						// alpha: 0.5, //透明度
						callout: { //自定义标记点上方的气泡窗口 点击有效  
							content: 'aquarium', //文本
							color: '#ffffff', //文字颜色
							fontSize: 15, //文本大小
							borderRadius: 15, //边框圆角
							padding: '10',
							bgColor: '#406390', //背景颜色
							display: 'ALWAYS', //常显
						}
					},
					{
						id: 1,
						latitude: 34.81977, //纬度
						longitude: 113.658072, //经度
						iconPath: '/static/logo.png', //显示的图标        
						rotate: 0, // 旋转度数
						width: 20, //宽
						height: 20, //高
						//title: '我在这里', //标注点名
						// alpha: 0.5, //透明度
						callout: { //自定义标记点上方的气泡窗口 点击有效  
							content: 'Botanical Garden', //文本
							color: '#ffffff', //文字颜色
							fontSize: 15, //文本大小
							borderRadius: 15, //边框圆角
							padding: '10',
							bgColor: '#406390', //背景颜色
							display: 'ALWAYS', //常显
						}
					}, {
						id: 2,
						latitude: 34.787774, //纬度
						longitude: 113.699542, //经度
						iconPath: '/static/logo.png', //显示的图标        
						rotate: 0, // 旋转度数
						width: 20, //宽
						height: 20, //高
						// title: '我在这里', //标注点名
						// alpha: 0.5, //透明度
						callout: { //自定义标记点上方的气泡窗口 点击有效  
							content: 'Zoo', //文本
							color: '#ffffff', //文字颜色
							fontSize: 15, //文本大小
							borderRadius: 15, //边框圆角
							padding: '10',
							bgColor: '#406390', //背景颜色
							display: 'ALWAYS', //常显
						}
					}, {
						id: 3,
						latitude: 34.82977, //纬度
						longitude: 113.658072, //经度
						iconPath: '/static/logo.png', //显示的图标        
						rotate: 0, // 旋转度数
						width: 20, //宽
						height: 20, //高
						// title: '我在这里', //标注点名
						// alpha: 0.5, //透明度
						callout: { //自定义标记点上方的气泡窗口 点击有效  
							content: 'Marine Museum', //文本
							color: '#ffffff', //文字颜色
							fontSize: 15, //文本大小
							borderRadius: 15, //边框圆角
							padding: '10',
							bgColor: '#406390', //背景颜色
							display: 'ALWAYS', //常显
						}
					}
					
				],
				lists:[],
				hhcontent:''
			}
		},
		onLoad() {
			this.init();
		},
		onReady() {
		 
		},
		computed: {},
		onLoad() {
		 
		},
		onShow() {
			this.getLocation1()
		},
		methods: {
			init(){
				this.$u.get('/jiezhongdian/findAll').then(res=>{
					console.log(res)
					if(res.success){
						this.list = res.data.map(function(item){
							return {
								label:item.name,
								value:item.id,
							
							}
						})
					}
				})
			},
			goto(res){
				uni.navigateTo({
					url:'../visitor/'+res,
				})
			},
			// showToast() {
			// 				this.$refs.uToast.show({
			// 					title: '登录成功',
			// 					type: 'success',
			// 					//url: '/pages/user/index'
			// 				})
			// 			},
			setJieZhongDian(res){
				
				this.form.jiezhongdianId =res[0].value;
				this.form.jiezhongdianName =res[0].label;
			},
			setDate(res){
				this.form.yuyueriqi=res.result;
			},
			yuYue(){
				this.isLoading=true;
				this.$u.post("/user/yuyue",this.form).then(res=>{
					if(res.success){
						uni.showModal({
						    title: '预约成功',
						    content: '您已经预约成功！请您准时在预约的时间到达预约接种点完成预约',
							showCancel:false,
						    success(res) {
								if (res.confirm) {
									uni.navigateBack();
								}
							}
							})
					}else{
						this.$refs.uToast.show({
							title :res.message,
							type : 'error'
						})
					}
				}).finally(()=>{
					this.isLoading=false;
				})
			},
			getLocation() {
				uni.getLocation({
					type: 'gcj02',
					success: res => {
						this.latitude = res.latitude
						this.longitude = res.longitude
					}
				});
			},
			getLocation1() {
				this.$u.get('/user/findAll').then(res=>{
					console.log(res)
					if(res.success){
						this.list=res.data;
						this.content01='hello'+this.list[0].num
						console.log(this.list[0].num)
					}
				})
			},
			refresh() {
				this.getLocation()
				console.log('刷新');
				//后期这里可加入调用请求接口的方法，用来实现刷新
			},
			refresh1() {
				this.getLocation1()
				console.log('刷新');
				//后期这里可加入调用请求接口的方法，用来实现刷新
			},
			//定位
			onControltap() {
				this.getLocation()
				uni.createMapContext("map", this).moveToLocation({ //moveToLocation将地图中心移动到当前定位点，需要配合map组件的show-location使用
					latitude: this.latitude,
					longitude: this.longitude,
				});
				console.log('定位');
			},
			//地图点击事件
			markertap(e) {
				console.log("你点击了标记点", e)
				uni.showModal({
					title: '提示',
					content: '地图点击事件，标记点'
				})
			},
			callouttap(e) {
				//console.log('你点击了气泡标签', e)
				console.log(this.list[0].num)
				if(e.detail.markerId== 0){
					//showToast();
							this.hhcontent='The reserved number of people: '+this.list[0].num
				}
				if(e.detail.markerId== 1){
							this.hhcontent='The reserved number of people'+this.list[1].num
				}
				if(e.detail.markerId== 2){
							this.hhcontent='The reserved number of people'+this.list[2].num
				}
				if(e.detail.markerId== 3){
							this.hhcontent='The reserved number of people'+this.list[3].num
				}
				// uni.showModal({
				// 	title: 'Attention',
				// 	//content: '地图点击事件，气泡标签'
				// 	content:this.hhcontent
				// 	//content: '你点击了'+e.detail.markerId
				// })
				uni.showToast({
				title: this.hhcontent,
				duration: 20000
				});
			}
			
		}
	}
</script>

<style scoped>
.page{
		padding: 50rpx;
		
	}
</style>
