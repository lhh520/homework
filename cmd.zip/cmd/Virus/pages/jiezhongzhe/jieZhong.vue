<template>
	<view class="page">
		<view v-if="qrCodePath">
			<u-image width="650rpx" height="650rpx" :src="qrCodePath"></u-image>
			<view>Show this QR code to the staff</view>
		</view>
		<view v-else>
			<u-empty text="暂无预约" mode="search"></u-empty>

		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				qrCodePath:''
				
			}
		},
		onLoad() {
			this.init();
		},
		methods: {
			init(){
				this.$u.get("/user/findMyYuyues").then(res=>{
					if(res.success){
						
						for(let i=0;i<res.data.length;i++){
							
							if(res.data[i].status==0){
								//https://edu-11144.oss-cn-beijing.aliyuncs.com/1e49dc10-bc33-4f2c-b5f3-5b7cee74a925.png
								//this.qrCodePath = this.$u.http.config.baseUrl + res.data[i].qrCodePath;
								this.qrCodePath='https://edu-11144.oss-cn-beijing.aliyuncs.com/1e49dc10-bc33-4f2c-b5f3-5b7cee74a925.png';
								console.log(this.qrCodePath);
							break;
							}
						}
					}
				})
			}
		}
	}
</script scoped>


<style>

</style>
