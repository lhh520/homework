<template>
	<view class="page">
		<!-- 这是接种者页面 -->
		<view v-if="userType == 'jiezhongzhe'">
			<u-cell-group>
				<u-cell-item @click="goto3('eat')" icon='pushpin' title="JUST EAT" label="There are fast food and other delicacies"></u-cell-item>
				<u-cell-item @click="goto('vistor_asign')" icon='pushpin' title="Appointment" label="Make an appointment"></u-cell-item>
				<!-- <u-cell-item @click="goto('yuYueList')" icon='order' title="预约历史记录" label="查看预约历史"></u-cell-item> -->
				<u-cell-item @click="goto('jieZhong')" icon='checkmark-circle' title="Appointment voucher" label="Arrive at the appointment site"></u-cell-item>
				<!-- <u-cell-item @click="goto('jieZhongList')" icon='list-dot' title="接种历史记录" label="查看疫苗接种历史"></u-cell-item> -->
			</u-cell-group>
		</view>
			
		
		<!-- 这是医护工作者 -->
		<view v-else>
			<u-cell-group>
				<u-cell-item @click="goto3('worker01')" icon='pushpin' title="Scanning code" label="Scan the code to complete the tourist reservation"></u-cell-item>
				<!-- <u-cell-item @click="goto2('qianDao')" icon='pushpin' title="签到" label="要接种先进行签到"></u-cell-item>
				<u-cell-item @click="goto2('yuJian')" icon='order' title="预检" label="查看预约历史"></u-cell-item>
				<u-cell-item @click="goto2('jieZhong')" icon='checkmark-circle' title="接种" label="到达预约现场后进入接种环节"></u-cell-item>
				<u-cell-item @click="goto2('liiuGuan')" icon='list-dot' title="留观" label="查看疫苗接种历史"></u-cell-item> -->
			</u-cell-group>
			
			<u-line/>
			
			<!-- <u-cell-group>
				<u-cell-item @click="goto2('qianDaoList')" icon='pushpin' title="签到历史" label="要接种先进行签到"></u-cell-item>
				<u-cell-item @click="goto2('yuJianList')" icon='order' title="预检历史" label="查看预约历史"></u-cell-item>
				<u-cell-item @click="goto2('jieZhongList')" icon='checkmark-circle' title="接种历史" label="到达预约现场后进入接种环节"></u-cell-item>
				<u-cell-item @click="goto2('liuGuanList')" icon='list-dot' title="留观历史" label="查看疫苗接种历史"></u-cell-item>
			</u-cell-group> -->
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userType:''
			}
		},
		onLoad(){
			this.init();
		},
		methods: {
			init(){
			
				this.userType=this.$store.state.userLogined.userType;
				console.log(this.userType)
			},
			goto(res){
				uni.navigateTo({
					url:'../jiezhongzhe/'+res,
				})
			},
			
			goto2(res){
				uni.navigateTo({
					url:'../worker/'+res,
				})
			},
			goto3(res){
				uni.navigateTo({
					url:'../visitor/'+res,
				})
			}
			
		}
	}
</script>

<style scoped>
		
</style>
